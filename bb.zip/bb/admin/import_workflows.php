<?php
require_once '../includes/db.php';
require_once '../includes/config.php';

// Basic authentication
session_start();
if (!isset($_SESSION['is_admin']) || !$_SESSION['is_admin']) {
    header('Location: login.php');
    exit;
}

// Include the workflow parsing function from index.php
require_once 'workflow_functions.php';

// Directory containing workflow files
$workflow_dir = '../workfollowapi/';

// Get all JSON files in the main directory
$workflow_files = glob($workflow_dir . '*.json');

// Get all category folders
$directories = array_filter(glob($workflow_dir . '*'), 'is_dir');

// Array to store all workflow files with their categories
$categorized_workflows = [];

// Add files from main directory (no category)
foreach ($workflow_files as $file_path) {
    $categorized_workflows[] = [
        'path' => $file_path,
        'category' => 'Uncategorized'
    ];
}

// Add files from each category folder
foreach ($directories as $dir) {
    $category_name = basename($dir);
    $category_files = glob($dir . '/*.json');
    
    foreach ($category_files as $file_path) {
        $categorized_workflows[] = [
            'path' => $file_path,
            'category' => $category_name
        ];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Import Workflows - Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="container mx-auto p-4">
        <header class="mb-8">
            <h1 class="text-3xl font-bold text-gray-800">Import Workflows</h1>
            <p class="text-gray-600">Import workflow files from workfollowapi folder and its categories</p>
            <div class="mt-4">
                <a href="index.php" class="bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors">
                    Back to Admin Panel
                </a>
            </div>
        </header>

        <div class="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 class="text-xl font-semibold text-gray-800 mb-4">Available Workflow Files</h2>
            
            <?php
            if (empty($categorized_workflows)) {
                echo '<p class="text-red-500">No workflow files found in the workfollowapi directory or its subdirectories.</p>';
            } else {
                // Group workflows by category
                $workflows_by_category = [];
                foreach ($categorized_workflows as $workflow) {
                    $category = $workflow['category'];
                    if (!isset($workflows_by_category[$category])) {
                        $workflows_by_category[$category] = [];
                    }
                    $workflows_by_category[$category][] = $workflow['path'];
                }
                
                // Display workflows by category
                foreach ($workflows_by_category as $category => $files) {
                    echo '<div class="mb-4">';
                    echo '<h3 class="text-lg font-medium text-gray-800 mb-2">' . htmlspecialchars($category) . '</h3>';
                    echo '<ul class="list-disc pl-5 space-y-2">';
                    foreach ($files as $file_path) {
                        $filename = basename($file_path);
                        echo '<li>' . htmlspecialchars($filename) . ' (' . round(filesize($file_path) / 1024, 2) . ' KB)</li>';
                    }
                    echo '</ul>';
                    echo '</div>';
                }
                
                echo '<div class="mt-6">';
                echo '<form method="POST" class="space-y-4">';
                echo '<button type="submit" class="w-full bg-green-600 text-white py-2 px-4 rounded-md hover:bg-green-700 transition-colors">
                        Import All Workflows
                      </button>';
                echo '</form>';
                echo '</div>';
            }
            ?>
        </div>

        <?php
        // Process the import if the form is submitted
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            echo '<div class="bg-white rounded-lg shadow-md p-6">';
            echo '<h2 class="text-xl font-semibold text-gray-800 mb-4">Import Results</h2>';
            
            $imported_count = 0;
            $errors = [];
            
            // Process each workflow file
            foreach ($categorized_workflows as $workflow_info) {
                $file_path = $workflow_info['path'];
                $category = $workflow_info['category'];
                $filename = basename($file_path);
                $name = pathinfo($filename, PATHINFO_FILENAME);
                
                echo "<div class='mb-4 pb-4 border-b border-gray-200'>";
                echo "<p class='font-semibold'>Processing: " . htmlspecialchars($filename) . " (Category: " . htmlspecialchars($category) . ")</p>";
                
                // Read the workflow file
                $jsonContent = file_get_contents($file_path);
                if (!$jsonContent) {
                    $errors[] = "Could not read file: {$filename}";
                    echo "<p class='text-red-500'>Could not read file</p>";
                    echo "</div>";
                    continue;
                }
                
                // Parse the workflow to extract inputs
                $inputs = parseWorkflowInputs($jsonContent);
                
                if (empty($inputs)) {
                    $errors[] = "No inputs found in workflow: {$filename}";
                    echo "<p class='text-red-500'>No inputs found in this workflow</p>";
                    echo "</div>";
                    continue;
                }
                
                // Copy the file to the uploads directory
                $new_filename = uniqid() . '_' . $filename;
                $target = UPLOAD_DIR . $new_filename;
                
                if (!copy($file_path, $target)) {
                    $errors[] = "Failed to copy file: {$filename}";
                    echo "<p class='text-red-500'>Failed to copy file</p>";
                    echo "</div>";
                    continue;
                }
                
                // Generate a description
                $description = "Imported workflow from {$category}/{$filename}";
                
                // Store in the database
                $stmt = $conn->prepare("INSERT INTO workflows (name, description, api_file, inputs, category) VALUES (?, ?, ?, ?, ?)");
                $inputsJson = json_encode($inputs);
                $stmt->bind_param("sssss", $name, $description, $new_filename, $inputsJson, $category);
                
                if ($stmt->execute()) {
                    $imported_count++;
                    echo "<p class='text-green-500'>Successfully imported</p>";
                    echo "<p class='text-sm text-gray-700 mt-2'>Detected inputs:</p>";
                    echo "<ul class='list-disc pl-5'>";
                    foreach ($inputs as $key => $input) {
                        echo "<li class='text-sm text-gray-600'>" . htmlspecialchars($input['label']) . 
                             " (Default: " . htmlspecialchars($input['default']) . ")</li>";
                    }
                    echo "</ul>";
                } else {
                    $errors[] = "Database error for {$filename}: " . $stmt->error;
                    echo "<p class='text-red-500'>Database error: " . htmlspecialchars($stmt->error) . "</p>";
                }
                
                $stmt->close();
                echo "</div>";
            }
            
            echo "<div class='mt-6 pt-4 border-t border-gray-200'>";
            echo "<h3 class='text-lg font-medium text-gray-800'>Import Summary</h3>";
            echo "<p class='mt-2'>" . ($imported_count > 0 ? 
                  "<span class='text-green-500 font-semibold'>Successfully imported {$imported_count} workflows</span>" : 
                  "<span class='text-red-500'>No workflows were imported</span>") . "</p>";
            
            if (!empty($errors)) {
                echo "<h4 class='text-md font-medium text-gray-800 mt-4'>Errors:</h4>";
                echo "<ul class='list-disc pl-5 mt-2'>";
                foreach ($errors as $error) {
                    echo "<li class='text-red-500'>" . htmlspecialchars($error) . "</li>";
                }
                echo "</ul>";
            }
            
            echo "</div>";
            echo "</div>";
        }
        ?>
    </div>
</body>
</html> 