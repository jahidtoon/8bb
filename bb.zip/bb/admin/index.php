<?php
require_once '../includes/db.php';
require_once '../includes/config.php';
require_once 'workflow_functions.php';

// Basic authentication (you should implement proper authentication)
session_start();
if (!isset($_SESSION['is_admin']) || !$_SESSION['is_admin']) {
    header('Location: login.php');
    exit;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $description = $_POST['description'] ?? '';
    $inputs = $_POST['inputs_json'] ?? '{}';
    $category = $_POST['category'] ?? 'Uncategorized';
    $point_cost = $_POST['point_cost'] ?? '10';
    
    // Validate inputs
    if (empty($name)) {
        $errors[] = 'Workflow name is required';
    }
    
    if (empty($errors)) {
        // Check if this is an edit or a new workflow
        if (isset($_POST['id'])) {
            // This is an edit
            $id = (int)$_POST['id'];
            
            // Check if a new file was uploaded
            $apiFile = null;
            if (isset($_FILES['workflow_file']) && $_FILES['workflow_file']['error'] === UPLOAD_ERR_OK) {
                $uploadResult = handleFileUpload($_FILES['workflow_file']);
                if (isset($uploadResult['error'])) {
                    $errors[] = $uploadResult['error'];
                } else {
                    $apiFile = $uploadResult['filename'];
                }
            }
            
            // Check if a demo image was uploaded
            $demoImage = null;
            if (isset($_FILES['demo_image']) && $_FILES['demo_image']['error'] === UPLOAD_ERR_OK) {
                $uploadResult = handleDemoImageUpload($_FILES['demo_image']);
                if (isset($uploadResult['error'])) {
                    $errors[] = $uploadResult['error'];
                } else {
                    $demoImage = $uploadResult['filename'];
                }
            }
            
            if (empty($errors)) {
                $point_cost = (int)$_POST['point_cost'];
                if (updateWorkflow($id, $name, $description, $apiFile, $inputs, $category, $point_cost, $demoImage)) {
                    $success = 'Workflow updated successfully';
                    // Reset the editing state
                    $editing = false;
                    $workflow = [];
                } else {
                    $errors[] = 'Failed to update workflow: ' . $conn->error;
                }
            }
        } else {
            // This is a new workflow
            // A file is required for new workflows
            if (!isset($_FILES['workflow_file']) || $_FILES['workflow_file']['error'] !== UPLOAD_ERR_OK) {
                $errors[] = 'Workflow file is required';
            } else {
                $uploadResult = handleFileUpload($_FILES['workflow_file']);
                if (isset($uploadResult['error'])) {
                    $errors[] = $uploadResult['error'];
                } else {
                    $apiFile = $uploadResult['filename'];
                    $point_cost = (int)$_POST['point_cost'];
                    
                    // Check if a demo image was uploaded
                    $demoImage = null;
                    if (isset($_FILES['demo_image']) && $_FILES['demo_image']['error'] === UPLOAD_ERR_OK) {
                        $uploadResult = handleDemoImageUpload($_FILES['demo_image']);
                        if (isset($uploadResult['error'])) {
                            $errors[] = $uploadResult['error'];
                        } else {
                            $demoImage = $uploadResult['filename'];
                        }
                    }
                    
                    if (addWorkflow($name, $description, $apiFile, $inputs, $category, $point_cost, $demoImage)) {
                        $success = 'Workflow added successfully';
                    } else {
                        $errors[] = 'Failed to add workflow: ' . $conn->error;
                    }
                }
            }
        }
    }
}

// Handle workflow deletion
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $stmt = $conn->prepare("SELECT api_file FROM workflows WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $workflow = $result->fetch_assoc();
    
    if ($workflow) {
        // Delete the API file
        $file = UPLOAD_DIR . $workflow['api_file'];
        if (file_exists($file)) {
            unlink($file);
        }
        
        // Delete from database
        $stmt = $conn->prepare("DELETE FROM workflows WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
    }
    $stmt->close();
    
    header('Location: index.php');
    exit;
}

// Get all workflows
$result = $conn->query("SELECT * FROM workflows ORDER BY category, name");

if (isset($_GET['edit'])) {
    $editing = true;
    $id = (int)$_GET['edit'];
    
    // Get workflow data
    $stmt = $conn->prepare("SELECT * FROM workflows WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $workflow = $result->fetch_assoc();
    $stmt->close();
    
    // If workflow not found, redirect back to the admin panel
    if (!$workflow) {
        header('Location: index.php');
        exit;
    }
    
    // Prepare form for editing
    echo '<script>document.addEventListener("DOMContentLoaded", function() {
            $("#editForm").show();
            $("#newWorkflowForm").hide();
          });</script>';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Workflows</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body class="bg-gray-100">
    <div class="container mx-auto p-4">
        <header class="mb-8">
            <div class="flex justify-between items-center mb-4">
                <h1 class="text-3xl font-bold text-gray-800">Workflow Management</h1>
                <div>
                    <a href="check_workflow_files.php" class="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors mr-2">
                        Check Workflow Files
                    </a>
                    <a href="cleanup_uploads.php" class="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 transition-colors mr-2">
                        Cleanup Files
                    </a>
                    <a href="../index.php" class="bg-gray-600 text-white px-4 py-2 rounded-md hover:bg-gray-700 transition-colors">
                        Back to Website
                    </a>
                </div>
            </div>
            <p class="text-gray-600">Manage your AI workflows</p>
            <div class="mt-4 flex space-x-2">
                <a href="dashboard.php" class="bg-yellow-600 text-white py-2 px-4 rounded-md hover:bg-yellow-700 transition-colors">
                    Dashboard
                </a>
                <a href="users.php" class="bg-purple-600 text-white py-2 px-4 rounded-md hover:bg-purple-700 transition-colors">
                    Manage Users
                </a>
                <a href="point_transactions.php" class="bg-green-600 text-white py-2 px-4 rounded-md hover:bg-green-700 transition-colors">
                    Point Transactions
                </a>
                <a href="import_workflows.php" class="bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors">
                    Import Workflows
                </a>
            </div>
        </header>

        <!-- Add New Workflow Form -->
        <div class="bg-white rounded-lg shadow-md p-6 mb-8" id="newWorkflowForm">
            <h2 class="text-xl font-semibold text-gray-800 mb-4">Add New Workflow</h2>
            <form method="POST" enctype="multipart/form-data" class="space-y-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Name</label>
                    <input type="text" name="name" required
                           class="w-full p-2 border rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Category</label>
                    <select name="category" class="w-full p-2 border rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                        <option value="Uncategorized">Uncategorized</option>
                        <?php
                        // Get existing categories from the database
                        $categories = [];
                        $categoryResult = $conn->query("SELECT DISTINCT category FROM workflows WHERE category != 'Uncategorized' ORDER BY category");
                        while ($categoryRow = $categoryResult->fetch_assoc()) {
                            $categories[] = $categoryRow['category'];
                            echo "<option value='" . htmlspecialchars($categoryRow['category']) . "'>" . htmlspecialchars($categoryRow['category']) . "</option>";
                        }
                        ?>
                        <option value="new">-- Add New Category --</option>
                    </select>
                </div>
                
                <div id="newCategoryField" style="display: none;">
                    <label class="block text-sm font-medium text-gray-700 mb-1">New Category Name</label>
                    <input type="text" name="new_category" class="w-full p-2 border rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Description</label>
                    <textarea name="description" rows="3" required
                              class="w-full p-2 border rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"></textarea>
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Point Cost</label>
                    <input type="number" name="point_cost" min="1" value="10" required
                           class="w-full p-2 border rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                    <p class="text-sm text-gray-500 mt-1">Number of points that will be deducted when a user generates with this workflow</p>
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Upload Workflow File (JSON)</label>
                    <input type="file" name="workflow_file" accept=".json" required
                           class="w-full p-2 border rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                           onchange="previewInputs(this)">
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Demo Image - Optional</label>
                    <input type="file" name="demo_image" accept="image/*"
                           class="w-full p-2 border rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                    <p class="text-sm text-gray-500 mt-1">Upload an image to show as a preview on the workflow card</p>
                </div>
                
                <div id="inputFields" class="hidden">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Select Input Fields</label>
                    <div id="inputFieldsList" class="space-y-2">
                        <!-- Input fields will be dynamically added here -->
                    </div>
                    <p class="text-sm text-gray-500 mt-2">Select the input fields that users will be able to modify:</p>
                </div>
                
                <!-- Hidden input to store the parsed inputs as JSON -->
                <input type="hidden" name="inputs_json" id="inputs_json" value="{}">
                
                <div id="inputs_preview" class="mt-4">
                    <!-- Inputs preview will be displayed here -->
                </div>
                
                <button type="submit" id="submitBtn"
                        class="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors">
                    Add Workflow
                </button>
            </form>
        </div>

        <!-- Edit Workflow Form -->
        <?php if (isset($editing) && $editing): ?>
        <div class="bg-white rounded-lg shadow-md p-6 mb-8" id="editForm">
            <h2 class="text-xl font-semibold text-gray-800 mb-4">Edit Workflow</h2>
            <form method="POST" enctype="multipart/form-data" class="space-y-4">
                <input type="hidden" name="id" value="<?php echo $workflow['id']; ?>">
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Name</label>
                    <input type="text" name="name" value="<?php echo htmlspecialchars($workflow['name']); ?>" required
                           class="w-full p-2 border rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Category</label>
                    <select name="category" class="w-full p-2 border rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                        <option value="Uncategorized" <?php echo $workflow['category'] === 'Uncategorized' ? 'selected' : ''; ?>>Uncategorized</option>
                        <?php
                        foreach ($categories as $cat) {
                            $selected = $workflow['category'] === $cat ? 'selected' : '';
                            echo "<option value='" . htmlspecialchars($cat) . "' $selected>" . htmlspecialchars($cat) . "</option>";
                        }
                        ?>
                        <option value="new">-- Add New Category --</option>
                    </select>
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Description</label>
                    <textarea name="description" rows="3" required
                              class="w-full p-2 border rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"><?php echo htmlspecialchars($workflow['description']); ?></textarea>
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Point Cost</label>
                    <input type="number" name="point_cost" min="1" value="<?php echo $workflow['point_cost']; ?>" required
                           class="w-full p-2 border rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                    <p class="text-sm text-gray-500 mt-1">Number of points that will be deducted when a user generates with this workflow</p>
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">API File (JSON) - Optional</label>
                    <input type="file" name="workflow_file" accept=".json"
                           class="w-full p-2 border rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                    <p class="text-sm text-gray-500 mt-1">Current file: <?php echo htmlspecialchars($workflow['api_file']); ?></p>
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Demo Image - Optional</label>
                    <input type="file" name="demo_image" accept="image/*"
                           class="w-full p-2 border rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                    <?php if (!empty($workflow['demo_image'])): ?>
                        <p class="text-sm text-gray-500 mt-1">Current demo image: <?php echo htmlspecialchars($workflow['demo_image']); ?></p>
                        <div class="mt-2">
                            <img src="../assets/images/demos/<?php echo htmlspecialchars($workflow['demo_image']); ?>" 
                                 alt="Demo image" class="h-32 object-cover rounded-md">
                        </div>
                    <?php else: ?>
                        <p class="text-sm text-gray-500 mt-1">No demo image uploaded</p>
                    <?php endif; ?>
                    <p class="text-sm text-gray-500 mt-1">Upload an image to show as a preview on the workflow card</p>
                </div>
                
                <div id="inputFields" class="hidden">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Select Input Fields</label>
                    <div id="inputFieldsList" class="space-y-2">
                        <!-- Input fields will be dynamically added here -->
                    </div>
                    <p class="text-sm text-gray-500 mt-2">Select the input fields that users will be able to modify:</p>
                </div>
                
                <!-- Hidden input to store the parsed inputs as JSON -->
                <input type="hidden" name="inputs_json" id="inputs_json" value="{}">
                
                <div id="inputs_preview" class="mt-4">
                    <!-- Inputs preview will be displayed here -->
                </div>
                
                <button type="submit" id="submitBtn"
                        class="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors">
                    Update Workflow
                </button>
            </form>
        </div>
        <?php endif; ?>

        <!-- Workflows List -->
        <div class="bg-white rounded-lg shadow-md overflow-hidden">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Points</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Inputs</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Demo</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Created</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php
                    // Get all workflows and display them
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            $inputs = json_decode($row['inputs'], true);
                            $inputCount = count($inputs);
                    ?>
                    <tr>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?php echo $row['id']; ?></td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($row['name']); ?></div>
                            <div class="text-sm text-gray-500"><?php echo substr(htmlspecialchars($row['description']), 0, 60) . (strlen($row['description']) > 60 ? '...' : ''); ?></div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?php echo htmlspecialchars($row['category']); ?></td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?php echo $row['point_cost']; ?></td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?php echo $inputCount; ?> input<?php echo $inputCount !== 1 ? 's' : ''; ?></td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            <?php if (!empty($row['demo_image'])): ?>
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                    <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                                    </svg>
                                    Yes
                                </span>
                            <?php else: ?>
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">No</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?php echo date('M j, Y', strtotime($row['created_at'])); ?></td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                            <a href="?edit=<?php echo $row['id']; ?>" class="text-blue-600 hover:text-blue-900 mr-3">Edit</a>
                            <a href="?delete=<?php echo $row['id']; ?>" class="text-red-600 hover:text-red-900" onclick="return confirm('Are you sure you want to delete this workflow?')">Delete</a>
                        </td>
                    </tr>
                    <?php
                        }
                    } else {
                        echo '<tr><td colspan="6" class="px-6 py-4 text-center text-gray-500">No workflows found</td></tr>';
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
    function previewInputs(fileInput) {
        const file = fileInput.files[0];
        if (!file) return;
        
        const reader = new FileReader();
        reader.onload = function(e) {
            try {
                const jsonContent = e.target.result;
                const inputsJson = document.getElementById('inputs_json');
                const inputsPreview = document.getElementById('inputs_preview');
                
                // Parse the workflow file
                fetch('workflow_functions.php?action=parse', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ content: jsonContent })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.error) {
                        inputsPreview.innerHTML = `<div class="text-red-500">${data.error}</div>`;
                        inputsJson.value = '{}';
                    } else {
                        // Display the inputs
                        inputsPreview.innerHTML = '';
                        const inputs = data.inputs;
                        
                        if (Object.keys(inputs).length === 0) {
                            inputsPreview.innerHTML = '<div class="text-yellow-500">No inputs detected in this workflow</div>';
                        } else {
                            const table = document.createElement('table');
                            table.className = 'min-w-full divide-y divide-gray-200';
                            
                            // Create header
                            const thead = document.createElement('thead');
                            thead.className = 'bg-gray-50';
                            thead.innerHTML = `
                                <tr>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Input</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Default</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Include</th>
                                </tr>
                            `;
                            table.appendChild(thead);
                            
                            // Create body
                            const tbody = document.createElement('tbody');
                            tbody.className = 'bg-white divide-y divide-gray-200';
                            
                            for (const [key, input] of Object.entries(inputs)) {
                                const row = document.createElement('tr');
                                row.innerHTML = `
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm font-medium text-gray-900">${input.label}</div>
                                        <div class="text-xs text-gray-500">${key}</div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${input.type}</td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${input.default}</td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <input type="checkbox" checked class="input-checkbox" data-key="${key}">
                                    </td>
                                `;
                                tbody.appendChild(row);
                            }
                            table.appendChild(tbody);
                            
                            inputsPreview.appendChild(table);
                            
                            // Add listener to update the inputs_json field when checkboxes change
                            const checkboxes = document.querySelectorAll('.input-checkbox');
                            checkboxes.forEach(checkbox => {
                                checkbox.addEventListener('change', updateSelectedInputs);
                            });
                            
                            // Set the initial value
                            inputsJson.value = JSON.stringify(inputs);
                        }
                    }
                })
                .catch(error => {
                    inputsPreview.innerHTML = `<div class="text-red-500">Error processing file: ${error.message}</div>`;
                    inputsJson.value = '{}';
                });
            } catch (error) {
                console.error('Error reading file:', error);
            }
        };
        reader.readAsText(file);
    }

    // Function to update the selected inputs
    function updateSelectedInputs() {
        const checkboxes = document.querySelectorAll('.input-checkbox');
        const inputsJson = document.getElementById('inputs_json');
        
        try {
            const allInputs = JSON.parse(inputsJson.value);
            const selectedInputs = {};
            
            checkboxes.forEach(checkbox => {
                const key = checkbox.dataset.key;
                if (checkbox.checked && allInputs[key]) {
                    selectedInputs[key] = allInputs[key];
                }
            });
            
            inputsJson.value = JSON.stringify(selectedInputs);
        } catch (error) {
            console.error('Error updating selected inputs:', error);
        }
    }

    document.addEventListener('DOMContentLoaded', function() {
        const categorySelect = document.querySelector('select[name="category"]');
        const newCategoryField = document.getElementById('newCategoryField');
        
        categorySelect.addEventListener('change', function() {
            if (this.value === 'new') {
                newCategoryField.style.display = 'block';
            } else {
                newCategoryField.style.display = 'none';
            }
        });
    });
    </script>
</body>
</html> 