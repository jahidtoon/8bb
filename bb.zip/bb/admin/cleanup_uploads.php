<?php
require_once '../includes/db.php';
require_once '../includes/config.php';
session_start();

// Check if user is admin
if (!isset($_SESSION['is_admin']) || !$_SESSION['is_admin']) {
    header('Location: login.php');
    exit;
}

$message = '';
$deleted = 0;

// Get all workflow files from database
$fileQuery = "SELECT api_file FROM workflows";
$result = $conn->query($fileQuery);
$usedFiles = [];

while ($row = $result->fetch_assoc()) {
    $usedFiles[] = $row['api_file'];
}

// Get all files in uploads directory
$uploadDir = UPLOAD_DIR;
$allFiles = scandir($uploadDir);
$jsonFiles = [];

foreach ($allFiles as $file) {
    if (pathinfo($file, PATHINFO_EXTENSION) === 'json') {
        $jsonFiles[] = $file;
    }
}

// Find and delete unused files
if (isset($_POST['cleanup'])) {
    foreach ($jsonFiles as $file) {
        if (!in_array($file, $usedFiles)) {
            $filePath = $uploadDir . $file;
            if (unlink($filePath)) {
                $deleted++;
            }
        }
    }
    $message = "$deleted unused files have been deleted.";
}

// Count files
$totalFiles = count($jsonFiles);
$unusedFiles = 0;

foreach ($jsonFiles as $file) {
    if (!in_array($file, $usedFiles)) {
        $unusedFiles++;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Cleanup - Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="container mx-auto p-4">
        <header class="mb-8">
            <div class="flex justify-between items-center mb-4">
                <h1 class="text-3xl font-bold text-gray-800">Upload Cleanup</h1>
                <div>
                    <a href="index.php" class="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors">
                        Back to Admin Panel
                    </a>
                </div>
            </div>
            <p class="text-gray-600">Manage uploaded workflow files</p>
        </header>

        <?php if (!empty($message)): ?>
            <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4" role="alert">
                <p><?php echo $message; ?></p>
            </div>
        <?php endif; ?>

        <div class="bg-white rounded-lg shadow-md p-6 mb-6">
            <h2 class="text-xl font-semibold mb-4">File Statistics</h2>
            <p>Total JSON files: <?php echo $totalFiles; ?></p>
            <p>Files used by workflows: <?php echo $totalFiles - $unusedFiles; ?></p>
            <p>Unused files: <?php echo $unusedFiles; ?></p>
            
            <?php if ($unusedFiles > 0): ?>
                <form method="POST" class="mt-4">
                    <button type="submit" name="cleanup" class="bg-red-600 text-white px-4 py-2 rounded-md hover:bg-red-700 transition-colors">
                        Delete Unused Files
                    </button>
                </form>
            <?php endif; ?>
        </div>
    </div>
</body>
</html> 