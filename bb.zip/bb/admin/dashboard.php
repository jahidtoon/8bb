<?php
require_once '../includes/db.php';
require_once '../includes/security.php';

// Check if user is admin
requireAdmin();

// Get total users
$userQuery = "SELECT COUNT(*) as total_users FROM users";
$userResult = $conn->query($userQuery);
$totalUsers = $userResult->fetch_assoc()['total_users'];

// Get active users in last 7 days
$activeQuery = "SELECT COUNT(*) as active_users FROM users WHERE last_login >= DATE_SUB(NOW(), INTERVAL 7 DAY)";
$activeResult = $conn->query($activeQuery);
$activeUsers = $activeResult->fetch_assoc()['active_users'];

// Get total workflows
$workflowQuery = "SELECT COUNT(*) as total_workflows FROM workflows";
$workflowResult = $conn->query($workflowQuery);
$totalWorkflows = $workflowResult->fetch_assoc()['total_workflows'];

// Get total generations
$genQuery = "SELECT COUNT(*) as total_generations FROM user_generations";
$genResult = $conn->query($genQuery);
$totalGenerations = $genResult->fetch_assoc()['total_generations'];

// Get generations per category
$categoryQuery = "SELECT category, COUNT(*) as count FROM user_generations GROUP BY category ORDER BY count DESC";
$categoryResult = $conn->query($categoryQuery);
$categoryData = [];

while ($row = $categoryResult->fetch_assoc()) {
    $categoryData[] = $row;
}

// Get generations in the last 30 days
$timelineQuery = "SELECT DATE(created_at) as date, COUNT(*) as count 
                  FROM user_generations 
                  WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
                  GROUP BY DATE(created_at)
                  ORDER BY date";
$timelineResult = $conn->query($timelineQuery);
$timeline = [];

while ($row = $timelineResult->fetch_assoc()) {
    $timeline[$row['date']] = $row['count'];
}

// Fill in missing dates
$endDate = new DateTime();
$startDate = new DateTime('-30 days');
$interval = new DateInterval('P1D');
$dateRange = new DatePeriod($startDate, $interval, $endDate);

$timelineData = [];
foreach ($dateRange as $date) {
    $dateStr = $date->format('Y-m-d');
    $timelineData[$dateStr] = isset($timeline[$dateStr]) ? $timeline[$dateStr] : 0;
}

// Get top users
$topUsersQuery = "SELECT u.username, COUNT(g.id) as generations 
                  FROM user_generations g
                  JOIN users u ON g.user_id = u.id
                  GROUP BY g.user_id
                  ORDER BY generations DESC
                  LIMIT 5";
$topUsersResult = $conn->query($topUsersQuery);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body class="bg-gray-100">
    <div class="container mx-auto p-4">
        <header class="mb-8">
            <div class="flex justify-between items-center mb-4">
                <h1 class="text-3xl font-bold text-gray-800">Admin Dashboard</h1>
                <div>
                    <a href="index.php" class="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors">
                        Back to Admin Panel
                    </a>
                </div>
            </div>
            <p class="text-gray-600">Overview of website statistics</p>
        </header>

        <!-- Stats overview -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <div class="bg-white p-6 rounded-lg shadow-md">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm text-gray-500 uppercase">Total Users</p>
                        <p class="text-3xl font-bold text-gray-800"><?php echo $totalUsers; ?></p>
                    </div>
                    <div class="p-3 bg-blue-100 rounded-full">
                        <svg class="w-8 h-8 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"></path>
                        </svg>
                    </div>
                </div>
            </div>
            
            <div class="bg-white p-6 rounded-lg shadow-md">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm text-gray-500 uppercase">Active Users (7d)</p>
                        <p class="text-3xl font-bold text-gray-800"><?php echo $activeUsers; ?></p>
                    </div>
                    <div class="p-3 bg-green-100 rounded-full">
                        <svg class="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z"></path>
                        </svg>
                    </div>
                </div>
            </div>
            
            <div class="bg-white p-6 rounded-lg shadow-md">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm text-gray-500 uppercase">Total Workflows</p>
                        <p class="text-3xl font-bold text-gray-800"><?php echo $totalWorkflows; ?></p>
                    </div>
                    <div class="p-3 bg-purple-100 rounded-full">
                        <svg class="w-8 h-8 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"></path>
                        </svg>
                    </div>
                </div>
            </div>
            
            <div class="bg-white p-6 rounded-lg shadow-md">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm text-gray-500 uppercase">Total Generations</p>
                        <p class="text-3xl font-bold text-gray-800"><?php echo $totalGenerations; ?></p>
                    </div>
                    <div class="p-3 bg-yellow-100 rounded-full">
                        <svg class="w-8 h-8 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                        </svg>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Charts -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            <div class="bg-white p-6 rounded-lg shadow-md">
                <h2 class="text-xl font-semibold mb-4">Generations by Category</h2>
                <canvas id="categoryChart" height="300"></canvas>
            </div>
            
            <div class="bg-white p-6 rounded-lg shadow-md">
                <h2 class="text-xl font-semibold mb-4">Generation Timeline (30 days)</h2>
                <canvas id="timelineChart" height="300"></canvas>
            </div>
        </div>
        
        <!-- Top users -->
        <div class="bg-white p-6 rounded-lg shadow-md mb-8">
            <h2 class="text-xl font-semibold mb-4">Top Users</h2>
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Username</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total Generations</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php while ($user = $topUsersResult->fetch_assoc()): ?>
                            <tr>
                                <td class="px-6 py-4 whitespace-nowrap"><?php echo htmlspecialchars($user['username']); ?></td>
                                <td class="px-6 py-4 whitespace-nowrap"><?php echo $user['generations']; ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <script>
        // Category chart
        const categoryCtx = document.getElementById('categoryChart').getContext('2d');
        const categoryChart = new Chart(categoryCtx, {
            type: 'pie',
            data: {
                labels: [
                    <?php
                    foreach ($categoryData as $row) {
                        echo "'" . htmlspecialchars($row['category']) . "', ";
                    }
                    ?>
                ],
                datasets: [{
                    data: [
                        <?php
                        foreach ($categoryData as $row) {
                            echo $row['count'] . ", ";
                        }
                        ?>
                    ],
                    backgroundColor: [
                        '#4F46E5', '#7C3AED', '#EC4899', '#EF4444', '#F59E0B',
                        '#10B981', '#3B82F6', '#6366F1', '#8B5CF6', '#EC4899'
                    ]
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'right',
                    }
                }
            }
        });
        
        // Timeline chart
        const timelineCtx = document.getElementById('timelineChart').getContext('2d');
        const timelineChart = new Chart(timelineCtx, {
            type: 'line',
            data: {
                labels: [
                    <?php
                    foreach ($timelineData as $date => $count) {
                        echo "'" . date('M d', strtotime($date)) . "', ";
                    }
                    ?>
                ],
                datasets: [{
                    label: 'Generations',
                    data: [
                        <?php
                        foreach ($timelineData as $count) {
                            echo $count . ", ";
                        }
                        ?>
                    ],
                    fill: false,
                    borderColor: '#4F46E5',
                    tension: 0.1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            precision: 0
                        }
                    }
                }
            }
        });
    </script>
</body>
</html> 