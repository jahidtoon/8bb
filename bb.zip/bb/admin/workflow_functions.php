<?php
// Function to parse ComfyUI workflow and extract input fields
function parseWorkflowInputs($jsonContent) {
    $workflow = json_decode($jsonContent, true);
    $inputs = [];
    
    // Debug output
    error_log("Starting workflow parsing...");
    
    if (json_last_error() !== JSON_ERROR_NONE) {
        error_log("JSON decode error: " . json_last_error_msg());
        return $inputs;
    }
    
    // Define default inputs to ensure they're always present
    $defaultInputs = [
        'prompt' => [
            'type' => 'textarea',
            'default' => 'a beautiful photo of a landscape',
            'label' => 'Prompt'
        ],
        'negative_prompt' => [
            'type' => 'textarea',
            'default' => 'text, watermark, bad quality, blurry',
            'label' => 'Negative Prompt'
        ],
        'seed' => [
            'type' => 'number',
            'default' => '42',
            'label' => 'Seed'
        ],
        'steps' => [
            'type' => 'number',
            'default' => '20',
            'label' => 'Steps'
        ],
        'cfg' => [
            'type' => 'number',
            'default' => '7',
            'label' => 'CFG Scale'
        ],
        'sampler_name' => [
            'type' => 'select',
            'default' => 'euler',
            'label' => 'Sampler'
        ],
        'scheduler' => [
            'type' => 'select',
            'default' => 'normal',
            'label' => 'Scheduler'
        ],
        'width' => [
            'type' => 'number',
            'default' => '512',
            'label' => 'Width'
        ],
        'height' => [
            'type' => 'number',
            'default' => '512',
            'label' => 'Height'
        ],
    ];

    if (!isset($workflow['nodes']) && !empty($workflow)) {
        // This might be a direct node structure without 'nodes' property
        // Try to process it as a flat structure where keys are node IDs
        error_log("No 'nodes' property found, treating as flat structure");
        
        // First pass: Find KSampler nodes to identify positive and negative connections
        $positiveNodeId = null;
        $negativeNodeId = null;
        
        foreach ($workflow as $nodeId => $node) {
            if (isset($node['class_type']) && 
                (strpos($node['class_type'], 'KSampler') !== false || strpos($node['class_type'], 'Sampler') !== false)) {
                if (isset($node['inputs']['positive']) && is_array($node['inputs']['positive'])) {
                    $positiveNodeId = $node['inputs']['positive'][0];
                    error_log("Found positive node ID: " . $positiveNodeId);
                }
                if (isset($node['inputs']['negative']) && is_array($node['inputs']['negative'])) {
                    $negativeNodeId = $node['inputs']['negative'][0];
                    error_log("Found negative node ID: " . $negativeNodeId);
                }
            }
        }
        
        // Second pass: Process all nodes
        foreach ($workflow as $nodeId => $node) {
            if (!isset($node['class_type'])) {
                continue;
            }
            
            error_log("Processing node type: " . $node['class_type'] . " (ID: $nodeId)");
            
            // Handle KSampler nodes
            if (strpos($node['class_type'], 'KSampler') !== false || 
                strpos($node['class_type'], 'Sampler') !== false) {
                error_log("Found sampler node");
                
                if (isset($node['inputs'])) {
                    foreach ($node['inputs'] as $key => $value) {
                        // Skip inputs that are arrays (typically connections to other nodes)
                        if (is_array($value)) {
                            continue;
                        }
                        
                        error_log("Sampler input: $key = $value");
                        
                        switch ($key) {
                            case 'seed':
                                $inputs['seed'] = [
                                    'type' => 'number',
                                    'default' => $value,
                                    'label' => 'Seed'
                                ];
                                break;
                            case 'steps':
                                $inputs['steps'] = [
                                    'type' => 'number',
                                    'default' => $value,
                                    'label' => 'Steps'
                                ];
                                break;
                            case 'cfg':
                                $inputs['cfg'] = [
                                    'type' => 'number',
                                    'default' => $value,
                                    'label' => 'CFG Scale'
                                ];
                                break;
                            case 'sampler_name':
                                $inputs['sampler_name'] = [
                                    'type' => 'select',
                                    'default' => $value,
                                    'label' => 'Sampler'
                                ];
                                break;
                            case 'scheduler':
                                $inputs['scheduler'] = [
                                    'type' => 'select',
                                    'default' => $value,
                                    'label' => 'Scheduler'
                                ];
                                break;
                        }
                    }
                }
            }
            
            // Handle CLIPTextEncode nodes - Check if this is a positive or negative prompt
            if (strpos($node['class_type'], 'CLIPTextEncode') !== false) {
                // Detect if this is a negative prompt node based on nodeId matching the negative connection
                $isNegativePrompt = ($nodeId === $negativeNodeId);
                
                // Also check meta title for "negative" keyword if available
                if (isset($node['_meta']['title']) && 
                    (stripos($node['_meta']['title'], 'negative') !== false)) {
                    $isNegativePrompt = true;
                }
                
                if ($isNegativePrompt) {
                    error_log("Found negative prompt node");
                    if (isset($node['inputs']['text']) && !is_array($node['inputs']['text'])) {
                        $inputs['negative_prompt'] = [
                            'type' => 'textarea',
                            'default' => $node['inputs']['text'],
                            'label' => 'Negative Prompt'
                        ];
                    }
                } else {
                    error_log("Found prompt node");
                    if (isset($node['inputs']['text']) && !is_array($node['inputs']['text'])) {
                        $inputs['prompt'] = [
                            'type' => 'textarea',
                            'default' => $node['inputs']['text'],
                            'label' => 'Prompt'
                        ];
                    }
                }
            }
            
            // Handle EmptyLatentImage or VAE nodes for dimensions
            if (strpos($node['class_type'], 'EmptyLatentImage') !== false ||
                strpos($node['class_type'], 'VAEEncode') !== false || 
                strpos($node['class_type'], 'VAEDecode') !== false) {
                error_log("Found image dimension node");
                if (isset($node['inputs']['width']) && !is_array($node['inputs']['width'])) {
                    $inputs['width'] = [
                        'type' => 'number',
                        'default' => $node['inputs']['width'],
                        'label' => 'Width'
                    ];
                }
                if (isset($node['inputs']['height']) && !is_array($node['inputs']['height'])) {
                    $inputs['height'] = [
                        'type' => 'number',
                        'default' => $node['inputs']['height'],
                        'label' => 'Height'
                    ];
                }
            }
        }
    } else if (isset($workflow['nodes'])) {
        // Standard structure with 'nodes' property
        error_log("Found " . count($workflow['nodes']) . " nodes in workflow");
        
        // First pass: Find KSampler nodes to identify positive and negative connections
        $positiveNodeId = null;
        $negativeNodeId = null;
        
        foreach ($workflow['nodes'] as $node) {
            if (isset($node['class_type']) && 
                (strpos($node['class_type'], 'KSampler') !== false || strpos($node['class_type'], 'Sampler') !== false)) {
                if (isset($node['inputs']['positive']) && is_array($node['inputs']['positive'])) {
                    $positiveNodeId = $node['inputs']['positive'][0];
                    error_log("Found positive node ID: " . $positiveNodeId);
                }
                if (isset($node['inputs']['negative']) && is_array($node['inputs']['negative'])) {
                    $negativeNodeId = $node['inputs']['negative'][0];
                    error_log("Found negative node ID: " . $negativeNodeId);
                }
            }
        }
        
        // Second pass: Process all nodes
        foreach ($workflow['nodes'] as $nodeId => $node) {
            if (!isset($node['class_type'])) {
                continue;
            }
            
            error_log("Processing node type: " . $node['class_type'] . " (ID: $nodeId)");
            
            // Handle KSampler nodes
            if (strpos($node['class_type'], 'KSampler') !== false || 
                strpos($node['class_type'], 'Sampler') !== false) {
                error_log("Found sampler node");
                
                if (isset($node['inputs'])) {
                    foreach ($node['inputs'] as $key => $value) {
                        // Skip inputs that are arrays (typically connections to other nodes)
                        if (is_array($value)) {
                            continue;
                        }
                        
                        error_log("Sampler input: $key = $value");
                        
                        switch ($key) {
                            case 'seed':
                                $inputs['seed'] = [
                                    'type' => 'number',
                                    'default' => $value,
                                    'label' => 'Seed'
                                ];
                                break;
                            case 'steps':
                                $inputs['steps'] = [
                                    'type' => 'number',
                                    'default' => $value,
                                    'label' => 'Steps'
                                ];
                                break;
                            case 'cfg':
                                $inputs['cfg'] = [
                                    'type' => 'number',
                                    'default' => $value,
                                    'label' => 'CFG Scale'
                                ];
                                break;
                            case 'sampler_name':
                                $inputs['sampler_name'] = [
                                    'type' => 'select',
                                    'default' => $value,
                                    'label' => 'Sampler'
                                ];
                                break;
                            case 'scheduler':
                                $inputs['scheduler'] = [
                                    'type' => 'select',
                                    'default' => $value,
                                    'label' => 'Scheduler'
                                ];
                                break;
                        }
                    }
                }
            }
            
            // Handle CLIPTextEncode nodes - Check if this is a positive or negative prompt
            if (strpos($node['class_type'], 'CLIPTextEncode') !== false) {
                // Detect if this is a negative prompt node based on nodeId matching the negative connection
                $isNegativePrompt = ($nodeId === $negativeNodeId);
                
                // Also check meta title for "negative" keyword if available
                if (isset($node['_meta']['title']) && 
                    (stripos($node['_meta']['title'], 'negative') !== false)) {
                    $isNegativePrompt = true;
                }
                
                if ($isNegativePrompt) {
                    error_log("Found negative prompt node");
                    if (isset($node['inputs']['text']) && !is_array($node['inputs']['text'])) {
                        $inputs['negative_prompt'] = [
                            'type' => 'textarea',
                            'default' => $node['inputs']['text'],
                            'label' => 'Negative Prompt'
                        ];
                    }
                } else {
                    error_log("Found prompt node");
                    if (isset($node['inputs']['text']) && !is_array($node['inputs']['text'])) {
                        $inputs['prompt'] = [
                            'type' => 'textarea',
                            'default' => $node['inputs']['text'],
                            'label' => 'Prompt'
                        ];
                    }
                }
            }
            
            // Handle EmptyLatentImage or VAE nodes for dimensions
            if (strpos($node['class_type'], 'EmptyLatentImage') !== false ||
                strpos($node['class_type'], 'VAEEncode') !== false || 
                strpos($node['class_type'], 'VAEDecode') !== false) {
                error_log("Found image dimension node");
                if (isset($node['inputs']['width']) && !is_array($node['inputs']['width'])) {
                    $inputs['width'] = [
                        'type' => 'number',
                        'default' => $node['inputs']['width'],
                        'label' => 'Width'
                    ];
                }
                if (isset($node['inputs']['height']) && !is_array($node['inputs']['height'])) {
                    $inputs['height'] = [
                        'type' => 'number',
                        'default' => $node['inputs']['height'],
                        'label' => 'Height'
                    ];
                }
            }
        }
    }
    
    // Merge with default inputs to ensure all standard fields are present,
    // but give priority to values found in the workflow
    foreach ($defaultInputs as $key => $value) {
        if (!isset($inputs[$key])) {
            $inputs[$key] = $value;
        }
    }
    
    error_log("Final inputs found: " . json_encode($inputs));
    return $inputs;
}

// Function to handle file upload
function handleFileUpload($file, $targetDir = UPLOAD_DIR) {
    global $conn;
    
    // Validate file
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['error' => 'File upload error: ' . $file['error']];
    }
    
    // Create a unique filename
    $filename = uniqid() . '_' . basename($file['name']);
    $target = $targetDir . $filename;
    
    // Move the uploaded file
    if (!move_uploaded_file($file['tmp_name'], $target)) {
        return ['error' => 'Failed to move uploaded file'];
    }
    
    return [
        'filename' => $filename,
        'path' => $target
    ];
}

// Function to handle demo image upload
function handleDemoImageUpload($file) {
    // Use a different directory for demo images
    $targetDir = '../assets/images/demos/';
    
    // Create the directory if it doesn't exist
    if (!is_dir($targetDir)) {
        mkdir($targetDir, 0755, true);
    }
    
    return handleFileUpload($file, $targetDir);
}

// Function to add a new workflow
function addWorkflow($name, $description, $apiFile, $inputs, $category, $pointCost = 10, $demoImage = null) {
    global $conn;
    
    // Use the new category if provided, otherwise use the selected one
    if ($category === 'new' && !empty($_POST['new_category'])) {
        $category = $_POST['new_category'];
    }
    
    $stmt = $conn->prepare("INSERT INTO workflows (name, description, api_file, inputs, category, point_cost, demo_image) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssis", $name, $description, $apiFile, $inputs, $category, $pointCost, $demoImage);
    $result = $stmt->execute();
    $stmt->close();
    return $result;
}

// Function to update an existing workflow
function updateWorkflow($id, $name, $description, $apiFile, $inputs, $category, $pointCost = null, $demoImage = null) {
    global $conn;
    
    // Use the new category if provided, otherwise use the selected one
    if ($category === 'new' && !empty($_POST['new_category'])) {
        $category = $_POST['new_category'];
    }
    
    if ($apiFile && $demoImage) {
        // If both new file and demo image were uploaded, update all fields
        $stmt = $conn->prepare("UPDATE workflows SET name = ?, description = ?, api_file = ?, inputs = ?, category = ?, point_cost = ?, demo_image = ? WHERE id = ?");
        $stmt->bind_param("ssssssii", $name, $description, $apiFile, $inputs, $category, $pointCost, $demoImage, $id);
    } elseif ($apiFile) {
        // If only a new file was uploaded
        $stmt = $conn->prepare("UPDATE workflows SET name = ?, description = ?, api_file = ?, inputs = ?, category = ?, point_cost = ? WHERE id = ?");
        $stmt->bind_param("sssssii", $name, $description, $apiFile, $inputs, $category, $pointCost, $id);
    } elseif ($demoImage) {
        // If only a new demo image was uploaded
        $stmt = $conn->prepare("UPDATE workflows SET name = ?, description = ?, inputs = ?, category = ?, point_cost = ?, demo_image = ? WHERE id = ?");
        $stmt->bind_param("ssssssi", $name, $description, $inputs, $category, $pointCost, $demoImage, $id);
    } else {
        // If no new files were uploaded
        $stmt = $conn->prepare("UPDATE workflows SET name = ?, description = ?, inputs = ?, category = ?, point_cost = ? WHERE id = ?");
        $stmt->bind_param("ssssii", $name, $description, $inputs, $category, $pointCost, $id);
    }
    
    $result = $stmt->execute();
    $stmt->close();
    return $result;
}

// Handle AJAX requests to parse workflow inputs
if (isset($_GET['action']) && $_GET['action'] === 'parse') {
    // This is an AJAX request to parse a workflow
    header('Content-Type: application/json');
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($input['content']) || empty($input['content'])) {
        echo json_encode(['error' => 'No content provided']);
        exit;
    }
    
    $jsonContent = $input['content'];
    $inputs = parseWorkflowInputs($jsonContent);
    
    echo json_encode([
        'inputs' => $inputs,
        'count' => count($inputs)
    ]);
    exit;
}
?> 