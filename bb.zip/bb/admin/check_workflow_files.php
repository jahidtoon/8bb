<?php
// Admin utility to check for and fix missing workflow files
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/security.php';

// Ensure the user is an admin
requireAdmin();

// Function to get all workflow files in the uploads directory
function getWorkflowFiles() {
    $files = [];
    $uploadsDir = UPLOAD_DIR;
    
    if (is_dir($uploadsDir)) {
        $dirContents = scandir($uploadsDir);
        foreach ($dirContents as $file) {
            if (pathinfo($file, PATHINFO_EXTENSION) === 'json') {
                $files[] = $file;
            }
        }
    }
    
    return $files;
}

// Process the fix if requested
$fixed = 0;
$errors = [];
if (isset($_POST['action']) && $_POST['action'] === 'fix') {
    $workflows = $_POST['workflows'] ?? [];
    $replacements = $_POST['replacements'] ?? [];
    
    foreach ($workflows as $index => $workflow_id) {
        if (isset($replacements[$index]) && !empty($replacements[$index])) {
            $replacement = $replacements[$index];
            
            try {
                $update_stmt = $conn->prepare("UPDATE workflows SET api_file = ? WHERE id = ?");
                $update_stmt->bind_param("si", $replacement, $workflow_id);
                $update_stmt->execute();
                $update_stmt->close();
                $fixed++;
            } catch (Exception $e) {
                $errors[] = "Error updating workflow ID $workflow_id: " . $e->getMessage();
            }
        }
    }
}

// Get all workflows from the database
$workflows = [];
$stmt = $conn->prepare("SELECT id, name, category, api_file FROM workflows ORDER BY category, name");
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $workflows[] = $row;
}
$stmt->close();

// Get all available workflow files
$available_files = getWorkflowFiles();

// Check each workflow for missing files
$missing_files = [];
foreach ($workflows as $workflow) {
    $file_path = UPLOAD_DIR . $workflow['api_file'];
    if (!file_exists($file_path)) {
        $missing_files[] = [
            'id' => $workflow['id'],
            'name' => $workflow['name'],
            'category' => $workflow['category'],
            'api_file' => $workflow['api_file']
        ];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Check Workflow Files - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #121212;
            color: #e0e0e0;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        .glass {
            background: rgba(30, 30, 40, 0.7);
            border-radius: 16px;
            box-shadow: 0 4px 30px rgba(0, 0, 0, 0.1);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            padding: 20px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="text-3xl font-bold mb-6">Check Workflow Files</h1>
        
        <div class="glass">
            <h2 class="text-xl font-semibold mb-4">Summary</h2>
            <p>Total workflows: <?php echo count($workflows); ?></p>
            <p>Missing workflow files: <?php echo count($missing_files); ?></p>
            <?php if ($fixed > 0): ?>
                <p class="text-green-400 mt-2">Fixed <?php echo $fixed; ?> workflow(s).</p>
            <?php endif; ?>
            <?php foreach ($errors as $error): ?>
                <p class="text-red-400 mt-2"><?php echo htmlspecialchars($error); ?></p>
            <?php endforeach; ?>
        </div>
        
        <?php if (count($missing_files) > 0): ?>
            <div class="glass">
                <h2 class="text-xl font-semibold mb-4">Missing Workflow Files</h2>
                <form method="post" action="">
                    <input type="hidden" name="action" value="fix">
                    <table class="w-full border-collapse">
                        <thead>
                            <tr class="bg-gray-800">
                                <th class="border border-gray-700 px-4 py-2 text-left">ID</th>
                                <th class="border border-gray-700 px-4 py-2 text-left">Name</th>
                                <th class="border border-gray-700 px-4 py-2 text-left">Category</th>
                                <th class="border border-gray-700 px-4 py-2 text-left">Missing File</th>
                                <th class="border border-gray-700 px-4 py-2 text-left">Replacement File</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($missing_files as $index => $workflow): ?>
                                <tr>
                                    <td class="border border-gray-700 px-4 py-2">
                                        <?php echo $workflow['id']; ?>
                                        <input type="hidden" name="workflows[]" value="<?php echo $workflow['id']; ?>">
                                    </td>
                                    <td class="border border-gray-700 px-4 py-2"><?php echo htmlspecialchars($workflow['name']); ?></td>
                                    <td class="border border-gray-700 px-4 py-2"><?php echo htmlspecialchars($workflow['category']); ?></td>
                                    <td class="border border-gray-700 px-4 py-2"><?php echo htmlspecialchars($workflow['api_file']); ?></td>
                                    <td class="border border-gray-700 px-4 py-2">
                                        <select name="replacements[]" class="w-full bg-gray-800 border border-gray-700 rounded px-3 py-2">
                                            <option value="">Select a replacement</option>
                                            <?php 
                                            // Try to find a similar file
                                            $suggested = null;
                                            $fileBaseName = '';
                                            
                                            // Extract base name (without timestamp)
                                            $fileNameParts = explode('_', $workflow['api_file'], 2);
                                            if (count($fileNameParts) > 1) {
                                                $fileBaseName = $fileNameParts[1];
                                            }
                                            
                                            foreach ($available_files as $file) {
                                                $selected = '';
                                                
                                                // Check if this file is a good match
                                                if (!empty($fileBaseName) && strpos($file, $fileBaseName) !== false) {
                                                    $selected = 'selected';
                                                    $suggested = $file;
                                                }
                                                
                                                echo "<option value=\"$file\" $selected>" . htmlspecialchars($file) . "</option>";
                                            }
                                            ?>
                                        </select>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <div class="mt-4">
                        <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded">
                            Fix Selected Workflows
                        </button>
                    </div>
                </form>
            </div>
        <?php else: ?>
            <div class="glass">
                <h2 class="text-xl font-semibold mb-4">All Workflow Files Found</h2>
                <p class="text-green-400">All workflow files are available in the uploads directory.</p>
            </div>
        <?php endif; ?>
        
        <div class="mt-4">
            <a href="index.php" class="text-blue-400 hover:text-blue-300">Back to Admin Dashboard</a>
        </div>
    </div>
</body>
</html> 