<?php
require_once '../includes/db.php';
require_once '../includes/config.php';

// Basic authentication (you should implement proper authentication)
session_start();
if (!isset($_SESSION['is_admin']) || !$_SESSION['is_admin']) {
    header('Location: login.php');
    exit;
}

// Initialize filters
$user_id = isset($_GET['user_id']) ? (int)$_GET['user_id'] : 0;
$type = isset($_GET['type']) ? $_GET['type'] : '';
$date_from = isset($_GET['date_from']) ? $_GET['date_from'] : '';
$date_to = isset($_GET['date_to']) ? $_GET['date_to'] : '';

// Build the query with optional filters
$query = "SELECT pt.*, u.username 
          FROM point_transactions pt
          JOIN users u ON pt.user_id = u.id
          WHERE 1=1";
$params = [];
$types = "";

if ($user_id > 0) {
    $query .= " AND pt.user_id = ?";
    $params[] = $user_id;
    $types .= "i";
}

if ($type === 'credit' || $type === 'debit') {
    $query .= " AND pt.transaction_type = ?";
    $params[] = $type;
    $types .= "s";
}

if (!empty($date_from)) {
    $query .= " AND DATE(pt.created_at) >= ?";
    $params[] = $date_from;
    $types .= "s";
}

if (!empty($date_to)) {
    $query .= " AND DATE(pt.created_at) <= ?";
    $params[] = $date_to;
    $types .= "s";
}

$query .= " ORDER BY pt.created_at DESC";

// Prepare and execute the query
$stmt = $conn->prepare($query);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();

// Get users for filter dropdown
$users_query = "SELECT id, username FROM users ORDER BY username";
$users_result = $conn->query($users_query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Point Transactions - Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="container mx-auto p-4">
        <header class="mb-8">
            <div class="flex justify-between items-center mb-4">
                <h1 class="text-3xl font-bold text-gray-800">Point Transactions</h1>
                <div>
                    <a href="users.php" class="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors mr-2">
                        User Management
                    </a>
                    <a href="index.php" class="bg-gray-600 text-white px-4 py-2 rounded-md hover:bg-gray-700 transition-colors">
                        Back to Admin Panel
                    </a>
                </div>
            </div>
            <p class="text-gray-600">View and filter point transaction history</p>
        </header>

        <!-- Filters -->
        <div class="bg-white rounded-lg shadow-md p-4 mb-6">
            <h2 class="text-lg font-semibold mb-3">Filter Transactions</h2>
            <form method="GET" class="flex flex-wrap items-end gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">User</label>
                    <select name="user_id" class="rounded-md border-gray-300 shadow-sm px-3 py-2">
                        <option value="0">All Users</option>
                        <?php while ($user = $users_result->fetch_assoc()): ?>
                            <option value="<?php echo $user['id']; ?>" <?php echo $user_id == $user['id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($user['username']); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Transaction Type</label>
                    <select name="type" class="rounded-md border-gray-300 shadow-sm px-3 py-2">
                        <option value="">All Types</option>
                        <option value="credit" <?php echo $type === 'credit' ? 'selected' : ''; ?>>Credit (Added)</option>
                        <option value="debit" <?php echo $type === 'debit' ? 'selected' : ''; ?>>Debit (Used)</option>
                    </select>
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Date From</label>
                    <input type="date" name="date_from" value="<?php echo $date_from; ?>" 
                           class="rounded-md border-gray-300 shadow-sm px-3 py-2">
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Date To</label>
                    <input type="date" name="date_to" value="<?php echo $date_to; ?>" 
                           class="rounded-md border-gray-300 shadow-sm px-3 py-2">
                </div>
                
                <div>
                    <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
                        Apply Filters
                    </button>
                    <a href="point_transactions.php" class="px-4 py-2 bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300 ml-2">
                        Clear Filters
                    </a>
                </div>
            </form>
        </div>

        <!-- Transactions Table -->
        <div class="bg-white rounded-lg shadow-md overflow-hidden">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">User</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Points</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Description</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php if ($result->num_rows === 0): ?>
                        <tr>
                            <td colspan="6" class="px-6 py-4 text-center text-gray-500">
                                No transactions found matching your filters.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php while ($transaction = $result->fetch_assoc()): ?>
                            <tr>
                                <td class="px-6 py-4 whitespace-nowrap"><?php echo $transaction['id']; ?></td>
                                <td class="px-6 py-4 whitespace-nowrap"><?php echo htmlspecialchars($transaction['username']); ?></td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <span class="<?php echo $transaction['transaction_type'] === 'credit' ? 'text-green-600' : 'text-red-600'; ?>">
                                        <?php echo $transaction['transaction_type'] === 'credit' ? '+' : '-'; ?><?php echo $transaction['points']; ?>
                                    </span>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <?php if ($transaction['transaction_type'] === 'credit'): ?>
                                        <span class="px-2 py-1 text-xs bg-green-100 text-green-800 rounded-full">Credit</span>
                                    <?php else: ?>
                                        <span class="px-2 py-1 text-xs bg-red-100 text-red-800 rounded-full">Debit</span>
                                    <?php endif; ?>
                                </td>
                                <td class="px-6 py-4"><?php echo htmlspecialchars($transaction['description']); ?></td>
                                <td class="px-6 py-4 whitespace-nowrap"><?php echo date('M j, Y g:i A', strtotime($transaction['created_at'])); ?></td>
                            </tr>
                        <?php endwhile; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html> 