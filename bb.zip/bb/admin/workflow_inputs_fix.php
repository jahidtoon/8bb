<?php
require_once __DIR__ . '/../includes/db.php';

// Connect to the database
$conn = new mysqli('localhost', 'root', '', 'ai_website_db');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Define default inputs that should be included in every workflow
$defaultInputs = [
    'prompt' => [
        'type' => 'textarea',
        'default' => 'a beautiful photo of a landscape',
        'label' => 'Prompt'
    ],
    'negative_prompt' => [
        'type' => 'textarea',
        'default' => 'text, watermark, bad quality, blurry',
        'label' => 'Negative Prompt'
    ],
    'seed' => [
        'type' => 'number',
        'default' => '42',
        'label' => 'Seed'
    ],
    'steps' => [
        'type' => 'number',
        'default' => '20',
        'label' => 'Steps'
    ],
    'cfg' => [
        'type' => 'number',
        'default' => '7',
        'label' => 'CFG Scale'
    ],
    'sampler_name' => [
        'type' => 'select',
        'default' => 'euler',
        'label' => 'Sampler'
    ],
    'scheduler' => [
        'type' => 'select',
        'default' => 'normal',
        'label' => 'Scheduler'
    ],
    'width' => [
        'type' => 'number',
        'default' => '512',
        'label' => 'Width'
    ],
    'height' => [
        'type' => 'number',
        'default' => '512',
        'label' => 'Height'
    ],
];

// Get all workflows
$result = $conn->query("SELECT id, name, inputs FROM workflows");

// Count of fixed workflows
$updatedCount = 0;

echo "<h2>Workflow Input Fix Tool</h2>";
echo "<p>This tool ensures all workflows have the required standard inputs.</p>";

// Process each workflow
while ($row = $result->fetch_assoc()) {
    $workflowId = $row['id'];
    $workflowName = $row['name'];
    $inputs = json_decode($row['inputs'], true);
    
    if (!$inputs) {
        $inputs = [];
        echo "<p>Workflow '$workflowName' (ID: $workflowId) has invalid or empty inputs JSON. Creating new inputs.</p>";
    }
    
    $needsUpdate = false;
    
    // Debug output
    echo "<h3>Workflow: $workflowName (ID: $workflowId)</h3>";
    echo "<p>Original inputs: ";
    echo htmlspecialchars(json_encode($inputs, JSON_PRETTY_PRINT));
    echo "</p>";
    
    // Merge default inputs with existing inputs
    foreach ($defaultInputs as $key => $defaultInput) {
        if (!isset($inputs[$key])) {
            $inputs[$key] = $defaultInput;
            $needsUpdate = true;
            echo "<p>Added missing input: $key</p>";
        } else {
            // Ensure the input has all required properties
            foreach (['type', 'default', 'label'] as $prop) {
                if (!isset($inputs[$key][$prop])) {
                    $inputs[$key][$prop] = $defaultInput[$prop];
                    $needsUpdate = true;
                    echo "<p>Fixed missing property '$prop' for input '$key'</p>";
                }
            }
        }
    }
    
    // Update the workflow if needed
    if ($needsUpdate) {
        $newInputsJson = json_encode($inputs);
        $stmt = $conn->prepare("UPDATE workflows SET inputs = ? WHERE id = ?");
        $stmt->bind_param("si", $newInputsJson, $workflowId);
        
        if ($stmt->execute()) {
            $updatedCount++;
            echo "<p class='success'>Updated workflow: $workflowName (ID: $workflowId)</p>";
            echo "<p>New inputs: ";
            echo htmlspecialchars(json_encode($inputs, JSON_PRETTY_PRINT));
            echo "</p>";
        } else {
            echo "<p class='error'>Failed to update workflow: $workflowName (ID: $workflowId) - " . $conn->error . "</p>";
        }
        
        $stmt->close();
    } else {
        echo "<p>No updates needed for this workflow.</p>";
    }
    
    echo "<hr>";
}

echo "<h3>Summary</h3>";
echo "<p>Fixed $updatedCount workflows to include standard parameters.</p>";
echo "<p><a href='../generate.php?id=6'>Try generating with workflow ID 6</a></p>";

// Close connection
$conn->close();
?>

<style>
body { font-family: Arial, sans-serif; margin: 2rem; }
h2 { color: #333; }
h3 { color: #555; margin-top: 1.5rem; }
p { margin: 0.5rem 0; }
hr { margin: 1.5rem 0; border: 0; border-top: 1px solid #ddd; }
.success { color: green; }
.error { color: red; }
</style> 