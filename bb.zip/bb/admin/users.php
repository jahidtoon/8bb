<?php
require_once '../includes/db.php';
require_once '../includes/config.php';

// Basic authentication (you should implement proper authentication)
session_start();
if (!isset($_SESSION['is_admin']) || !$_SESSION['is_admin']) {
    header('Location: login.php');
    exit;
}

// Create point_transactions table if it doesn't exist
$table_check_query = "SHOW TABLES LIKE 'point_transactions'";
$table_check_result = $conn->query($table_check_query);
if ($table_check_result->num_rows == 0) {
    // Table doesn't exist, create it
    $create_table_sql = "CREATE TABLE IF NOT EXISTS point_transactions (
        id INT(11) NOT NULL AUTO_INCREMENT,
        user_id INT(11) NOT NULL,
        points INT(11) NOT NULL,
        description VARCHAR(255) NOT NULL,
        transaction_type ENUM('credit', 'debit') NOT NULL,
        created_at DATETIME NOT NULL,
        PRIMARY KEY (id),
        KEY user_id (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    
    if (!$conn->query($create_table_sql)) {
        die("Error creating point_transactions table: " . $conn->error);
    }
}

// Handle user status change
if (isset($_GET['toggle_status']) && isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $query = "SELECT status FROM users WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    
    if ($user) {
        $newStatus = ($user['status'] === 'active') ? 'disabled' : 'active';
        $updateQuery = "UPDATE users SET status = ? WHERE id = ?";
        $updateStmt = $conn->prepare($updateQuery);
        $updateStmt->bind_param("si", $newStatus, $id);
        $updateStmt->execute();
        $updateStmt->close();
    }
    $stmt->close();
    header('Location: users.php');
    exit;
}

// Handle usage limit update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_limit'])) {
    $id = (int)$_POST['user_id'];
    $limit = (int)$_POST['usage_limit'];
    
    $query = "UPDATE users SET usage_limit = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ii", $limit, $id);
    $stmt->execute();
    $stmt->close();
    
    header('Location: users.php');
    exit;
}

// Handle point top-up
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_points'])) {
    $id = (int)$_POST['user_id'];
    $points = (int)$_POST['points_to_add'];
    
    if ($points > 0) {
        $query = "UPDATE users SET points = points + ? WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ii", $points, $id);
        $stmt->execute();
        $stmt->close();
        
        // Add record to point transaction log
        $log_query = "INSERT INTO point_transactions (user_id, points, description, transaction_type, created_at) 
                      VALUES (?, ?, 'Admin top-up', 'credit', NOW())";
        $log_stmt = $conn->prepare($log_query);
        $log_stmt->bind_param("ii", $id, $points);
        $log_stmt->execute();
        $log_stmt->close();
    }
    
    header('Location: users.php');
    exit;
}

// Fetch all users
$query = "SELECT id, username, email, full_name, created_at, last_login, status, usage_count, usage_limit, points, is_admin FROM users ORDER BY id";
$result = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management - Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="container mx-auto p-4">
        <header class="mb-8">
            <div class="flex justify-between items-center mb-4">
                <h1 class="text-3xl font-bold text-gray-800">User Management</h1>
                <div>
                    <a href="index.php" class="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors">
                        Back to Admin Panel
                    </a>
                </div>
            </div>
            <p class="text-gray-600">Manage users, usage limits, and points</p>
        </header>

        <div class="bg-white rounded-lg shadow-md overflow-hidden">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Username</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Full Name</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Created</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Last Login</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Usage</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Points</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php while ($user = $result->fetch_assoc()): ?>
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <?php echo htmlspecialchars($user['username']); ?>
                                <?php if ($user['is_admin']): ?>
                                    <span class="ml-1 px-2 py-1 text-xs bg-purple-100 text-purple-800 rounded-full">Admin</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap"><?php echo htmlspecialchars($user['email']); ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?php echo htmlspecialchars($user['full_name']); ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?php echo date('M j, Y', strtotime($user['created_at'])); ?></td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <?php echo $user['last_login'] ? date('M j, Y', strtotime($user['last_login'])) : 'Never'; ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <?php if ($user['status'] === 'active'): ?>
                                    <span class="px-2 py-1 text-xs bg-green-100 text-green-800 rounded-full">Active</span>
                                <?php else: ?>
                                    <span class="px-2 py-1 text-xs bg-red-100 text-red-800 rounded-full">Disabled</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <form method="POST" class="flex items-center space-x-2">
                                    <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                    <span><?php echo $user['usage_count']; ?> / </span>
                                    <input type="number" name="usage_limit" value="<?php echo $user['usage_limit']; ?>" 
                                           class="w-16 px-2 py-1 border rounded-md">
                                    <button type="submit" name="update_limit" 
                                            class="px-2 py-1 bg-blue-600 text-white text-xs rounded-md hover:bg-blue-700">
                                        Update
                                    </button>
                                </form>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <form method="POST" class="flex items-center space-x-2">
                                    <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                    <span class="font-semibold"><?php echo $user['points']; ?></span>
                                    <div class="flex space-x-1">
                                        <input type="number" name="points_to_add" placeholder="Add" min="1" 
                                               class="w-16 px-2 py-1 border rounded-md" required>
                                        <button type="submit" name="add_points" 
                                                class="px-2 py-1 bg-green-600 text-white text-xs rounded-md hover:bg-green-700">
                                            Add
                                        </button>
                                    </div>
                                </form>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <a href="?toggle_status=1&id=<?php echo $user['id']; ?>" 
                                   class="text-blue-600 hover:text-blue-900">
                                    <?php echo $user['status'] === 'active' ? 'Disable' : 'Enable'; ?>
                                </a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html> 