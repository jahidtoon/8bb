<?php
require_once '../includes/db.php';
session_start();

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Ensure username is set in session
if (!isset($_SESSION['username'])) {
    // Try to get username from database
    $username_stmt = $conn->prepare("SELECT username FROM users WHERE id = ?");
    $username_stmt->bind_param("i", $user_id);
    $username_stmt->execute();
    $username_result = $username_stmt->get_result();
    if ($username_row = $username_result->fetch_assoc()) {
        $_SESSION['username'] = $username_row['username'];
    } else {
        $_SESSION['username'] = 'User';
    }
    $username_stmt->close();
}

// Pagination settings
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$per_page = 24; // Divisible by 2, 3, 4 for responsive grids
$offset = ($page - 1) * $per_page;

// Filters
$gallery_filter = isset($_GET['gallery']) ? (int)$_GET['gallery'] : 0;
$filter_condition = $gallery_filter ? " AND g.save_to_gallery = 1" : "";

$category_filter = isset($_GET['category']) ? $conn->real_escape_string($_GET['category']) : '';
$category_condition = $category_filter ? " AND (w.category = '$category_filter' OR g.category = '$category_filter')" : "";

// Get unique categories for filter dropdown - more efficient query
$cat_stmt = $conn->prepare("
    SELECT DISTINCT COALESCE(w.category, g.category) as category 
    FROM user_generations g
    LEFT JOIN workflows w ON g.workflow_id = w.id
    WHERE g.user_id = ? AND COALESCE(w.category, g.category) IS NOT NULL
    ORDER BY category
");
$cat_stmt->bind_param("i", $user_id);
$cat_stmt->execute();
$categories_result = $cat_stmt->get_result();
$categories = [];
while ($cat_row = $categories_result->fetch_assoc()) {
    $categories[] = $cat_row['category'];
}
$cat_stmt->close();

// Get user's total generations count with faster counting technique
$count_query = "SELECT COUNT(*) as total FROM user_generations g 
          LEFT JOIN workflows w ON g.workflow_id = w.id
          WHERE g.user_id = ?" . $filter_condition . $category_condition;
$stmt = $conn->prepare($count_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$total_rows = $result->fetch_assoc()['total'];
$stmt->close();

$total_pages = ceil($total_rows / $per_page);

// Get user's generations with pagination and optimized query
$stmt = $conn->prepare("
    SELECT g.id, g.workflow_id, g.workflow_name, COALESCE(w.category, g.category) as category, 
           g.image_url, g.filename, g.created_at, g.save_to_gallery
    FROM user_generations g
    LEFT JOIN workflows w ON g.workflow_id = w.id
    WHERE g.user_id = ?" . $filter_condition . $category_condition . "
    ORDER BY g.created_at DESC
    LIMIT ?, ?
");
$stmt->bind_param("iii", $user_id, $offset, $per_page);
$stmt->execute();
$generations = $stmt->get_result();
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
    <meta name="theme-color" content="#9c42f5">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="description" content="Your Generated Content - ByteBrain">
    <title>Generation History - ByteBrain</title>
    <link rel="preconnect" href="https://cdn.jsdelivr.net">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/main.css">
    <link rel="manifest" href="../manifest.json">
    <link rel="apple-touch-icon" href="../images/icon-192x192.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* Critical styles */
        :root {
            --glass-bg: rgba(30, 30, 40, 0.7);
            --glass-border: rgba(255, 255, 255, 0.1);
            --glass-shadow: 0 4px 30px rgba(0, 0, 0, 0.1);
            --accent-color: rgba(138, 43, 226, 0.8);
        }
        
        body {
            background-color: #121212;
            color: #e0e0e0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        /* Add conditional loading for animations */
        @media (prefers-reduced-motion: no-preference) {
            body {
                background-image: 
                    radial-gradient(circle at 25% 25%, rgba(138, 43, 226, 0.1) 0%, transparent 50%),
                    radial-gradient(circle at 75% 75%, rgba(25, 118, 210, 0.1) 0%, transparent 50%);
            }
            
            .glass:hover {
                transform: translateY(-4px);
            }
        }
        
        .glass {
            background: var(--glass-bg);
            border-radius: 16px;
            box-shadow: var(--glass-shadow);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border: 1px solid var(--glass-border);
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }
        
        .glass:hover {
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
            border-color: rgba(255, 255, 255, 0.2);
        }
        
        .glass-btn {
            background: rgba(80, 80, 120, 0.4);
            backdrop-filter: blur(5px);
            -webkit-backdrop-filter: blur(5px);
            border: 1px solid var(--glass-border);
            transition: background 0.2s ease;
        }
        
        .glass-btn:hover {
            background: rgba(100, 100, 140, 0.5);
            border-color: rgba(255, 255, 255, 0.2);
        }
        
        .glass-navbar {
            background: rgba(20, 20, 30, 0.8);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-bottom: 1px solid var(--glass-border);
            z-index: 100;
        }
        
        .glass-footer {
            background: rgba(20, 20, 30, 0.8);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-top: 1px solid var(--glass-border);
        }
        
        .active-filter {
            background: rgba(138, 43, 226, 0.3);
            color: white;
        }
        
        .gallery-item {
            position: relative;
            overflow: hidden;
            transition: all 0.3s ease;
            aspect-ratio: 1 / 1;
            content-visibility: auto;
            contain-intrinsic-size: 0 250px;
        }
        
        .gallery-item:hover .gallery-overlay {
            opacity: 1;
        }
        
        .gallery-overlay {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            background: rgba(0, 0, 0, 0.7);
            width: 100%;
            height: 0;
            transition: .3s ease;
            opacity: 0;
        }
        
        .gallery-item:hover .gallery-overlay {
            height: 35%;
        }
        
        .masonry-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
            grid-gap: 16px;
            grid-auto-flow: dense;
        }
        
        /* Optimize image loading */
        .lazy-image {
            opacity: 0;
            transition: opacity 0.3s;
        }
        
        .lazy-image.loaded {
            opacity: 1;
        }
        
        /* Add loading skeleton */
        .skeleton {
            background: linear-gradient(90deg, rgba(255,255,255,0.05) 25%, rgba(255,255,255,0.1) 50%, rgba(255,255,255,0.05) 75%);
            background-size: 200% 100%;
            animation: skeleton-loading 1.5s infinite;
        }
        
        @keyframes skeleton-loading {
            0% { background-position: 200% 0; }
            100% { background-position: -200% 0; }
        }
    </style>
</head>
<body>
    <div class="min-h-screen">
        <header class="glass-navbar">
            <div class="container mx-auto px-4 max-w-7xl">
                <div class="flex justify-between h-16 items-center">
                    <div class="flex items-center">
                        <a href="../index.php" class="text-blue-400 text-2xl font-bold flex items-center">
                            <span class="text-gradient">ByteBrain</span>
                        </a>
                    </div>
                    <div class="flex items-center">
                        <span class="text-gray-300 hidden sm:inline mr-4">Welcome, <?php echo htmlspecialchars($_SESSION['username'] ?? 'User'); ?></span>
                        <a href="profile.php" class="text-blue-300 hover:text-blue-100 px-4 py-2">Profile</a>
                        <a href="logout.php" class="glass-btn text-white px-3 py-1 rounded-md">Logout</a>
                    </div>
                </div>
            </div>
        </header>
        
        <main class="container mx-auto px-4 py-6 max-w-7xl">
            <div class="flex flex-col md:flex-row justify-between items-center mb-5">
                <h1 class="text-2xl sm:text-3xl font-bold text-white mb-3 md:mb-0">Image Gallery</h1>
                
                <div class="flex flex-wrap justify-center gap-2">
                    <!-- Category filter dropdown -->
                    <?php if (!empty($categories)): ?>
                    <div class="relative inline-block">
                        <select 
                            onchange="window.location = this.value" 
                            class="glass-btn px-3 py-1 rounded-md appearance-none pr-8 cursor-pointer text-sm"
                        >
                            <option value="?<?php echo $gallery_filter ? 'gallery=1' : ''; ?>">All Categories</option>
                            <?php foreach($categories as $cat): ?>
                                <option 
                                    value="?category=<?php echo urlencode($cat); ?><?php echo $gallery_filter ? '&gallery=1' : ''; ?>" 
                                    <?php echo $category_filter === $cat ? 'selected' : ''; ?>
                                >
                                    <?php echo htmlspecialchars($cat); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-white">
                            <i class="fas fa-chevron-down text-xs"></i>
                        </div>
                    </div>
                    <?php endif; ?>

                    <!-- Gallery/All filter buttons -->
                    <a href="?<?php echo $category_filter ? 'category=' . urlencode($category_filter) : ''; ?>" 
                       class="px-3 py-1 rounded-md glass-btn text-sm <?php echo $gallery_filter == 0 ? 'active-filter' : ''; ?>">
                        All Images
                    </a>
                    <a href="?gallery=1<?php echo $category_filter ? '&category=' . urlencode($category_filter) : ''; ?>" 
                       class="px-3 py-1 rounded-md glass-btn text-sm <?php echo $gallery_filter == 1 ? 'active-filter' : ''; ?>">
                        Gallery Only
                    </a>
                </div>
            </div>
            
            <?php if ($generations->num_rows > 0): ?>
                <!-- Gallery grid layout -->
                <div class="masonry-grid mb-6" id="masonry-grid">
                    <?php 
                    $index = 0;
                    while ($generation = $generations->fetch_assoc()): 
                        $index++;
                        
                        // Determine image source
                        $image_src = '';
                        if (!empty($generation['image_url'])) {
                            $image_src = htmlspecialchars($generation['image_url']);
                        } elseif (!empty($generation['filename'])) {
                            $image_src = "../uploads/" . htmlspecialchars($generation['filename']);
                        }
                        
                        // Calculate random span for masonry layout
                        $span_class = '';
                        if ($index % 7 === 0) {
                            $span_class = 'md:col-span-2 md:row-span-2';
                        } elseif ($index % 5 === 0) {
                            $span_class = 'md:col-span-2';
                        } elseif ($index % 11 === 0) {
                            $span_class = 'md:row-span-2';
                        }
                    ?>
                        <div class="gallery-item glass overflow-hidden <?php echo $span_class; ?>">
                            <?php if (!empty($image_src)): ?>
                                <a href="<?php echo $image_src; ?>" target="_blank" class="block h-full">
                                    <div class="w-full h-full skeleton"></div>
                                    <img 
                                        src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" 
                                        data-src="<?php echo $image_src; ?>" 
                                        alt="Generated image" 
                                        class="lazy-image w-full h-full object-cover absolute top-0 left-0"
                                        loading="lazy"
                                    >
                                    <div class="gallery-overlay p-3">
                                        <h3 class="text-white font-semibold truncate">
                                            <?php echo htmlspecialchars($generation['workflow_name'] ?? 'Unnamed workflow'); ?>
                                        </h3>
                                        <p class="text-gray-300 text-xs">
                                            <?php echo htmlspecialchars($generation['category'] ?? 'Uncategorized'); ?>
                                        </p>
                                        <p class="text-gray-400 text-xs">
                                            <?php echo date('M j, Y', strtotime($generation['created_at'])); ?>
                                        </p>
                                    </div>
                                                </a>
                                            <?php else: ?>
                                <div class="h-full flex items-center justify-center bg-gray-800">
                                    <span class="text-gray-400">No image</span>
                    </div>
                <?php endif; ?>
                        </div>
                    <?php endwhile; ?>
                </div>
                
                <!-- Pagination -->
                <?php if ($total_pages > 1): ?>
                    <div class="flex justify-center mt-5">
                        <nav class="inline-flex rounded-md shadow-sm">
                            <?php 
                            $query_params = [];
                            if ($gallery_filter) $query_params[] = 'gallery=1';
                            if ($category_filter) $query_params[] = 'category=' . urlencode($category_filter);
                            $query_string = !empty($query_params) ? '&' . implode('&', $query_params) : '';
                            ?>
                            
                            <?php if ($page > 1): ?>
                                <a href="?page=<?php echo $page - 1; ?><?php echo $query_string; ?>" class="relative inline-flex items-center px-3 py-1 glass-btn text-sm font-medium text-white">
                                    <i class="fas fa-chevron-left mr-1"></i> Prev
                                </a>
                            <?php endif; ?>
                            
                            <?php 
                            // Show limited page numbers with ellipsis
                            $start_page = max(1, $page - 1);
                            $end_page = min($total_pages, $page + 1);
                            
                            if ($start_page > 1): ?>
                                <a href="?page=1<?php echo $query_string; ?>" class="relative inline-flex items-center px-2 py-1 glass-btn text-sm font-medium text-white">1</a>
                                <?php if ($start_page > 2): ?>
                                    <span class="relative inline-flex items-center px-1 py-1 text-sm font-medium text-white">...</span>
                                <?php endif; ?>
                            <?php endif; ?>
                            
                            <?php for ($i = $start_page; $i <= $end_page; $i++): ?>
                                <?php if ($i == $page): ?>
                                    <span class="relative inline-flex items-center px-2 py-1 active-filter text-sm font-medium text-white">
                                        <?php echo $i; ?>
                                    </span>
                                <?php else: ?>
                                    <a href="?page=<?php echo $i; ?><?php echo $query_string; ?>" class="relative inline-flex items-center px-2 py-1 glass-btn text-sm font-medium text-white">
                                        <?php echo $i; ?>
                                    </a>
                                <?php endif; ?>
                            <?php endfor; ?>
                            
                            <?php if ($end_page < $total_pages): ?>
                                <?php if ($end_page < $total_pages - 1): ?>
                                    <span class="relative inline-flex items-center px-1 py-1 text-sm font-medium text-white">...</span>
                                <?php endif; ?>
                                <a href="?page=<?php echo $total_pages; ?><?php echo $query_string; ?>" class="relative inline-flex items-center px-2 py-1 glass-btn text-sm font-medium text-white">
                                    <?php echo $total_pages; ?>
                                </a>
                            <?php endif; ?>
                            
                            <?php if ($page < $total_pages): ?>
                                <a href="?page=<?php echo $page + 1; ?><?php echo $query_string; ?>" class="relative inline-flex items-center px-3 py-1 glass-btn text-sm font-medium text-white">
                                    Next <i class="fas fa-chevron-right ml-1"></i>
                                </a>
                            <?php endif; ?>
                        </nav>
                    </div>
                <?php endif; ?>
            <?php else: ?>
                <div class="glass p-5 text-center">
                    <p class="text-gray-300">
                        <?php echo $gallery_filter ? "You don't have any images saved to your gallery yet." : "You haven't generated any content yet."; ?>
                    </p>
                    <a href="../index.php" class="mt-3 inline-block px-4 py-2 rounded-md glass-btn">
                        <i class="fas fa-magic mr-2"></i> Start Generating Content
                    </a>
                </div>
            <?php endif; ?>
        </main>
        
        <footer class="glass-footer py-4 mt-6">
            <div class="container mx-auto px-4 text-center text-gray-400 text-sm">
                <p>&copy; <?php echo date('Y'); ?> AI Generator. All rights reserved.</p>
            </div>
        </footer>
    </div>
    
    <script>
    // Modern optimized JavaScript
    document.addEventListener('DOMContentLoaded', function() {
        // Lazy load images for better performance
        const lazyImages = document.querySelectorAll('.lazy-image');
        
        if ('IntersectionObserver' in window) {
            const imageObserver = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const img = entry.target;
                        img.src = img.dataset.src;
                        img.onload = () => {
                            img.classList.add('loaded');
                            img.previousElementSibling?.remove(); // Remove skeleton
                        };
                        imageObserver.unobserve(img);
                    }
                });
            }, {
                rootMargin: '50px 0px',
                threshold: 0.01
            });
            
            lazyImages.forEach(img => {
                imageObserver.observe(img);
            });
        } else {
            // Fallback for browsers without Intersection Observer
            lazyImages.forEach(img => {
                img.src = img.dataset.src;
                img.classList.add('loaded');
            });
        }
    });
    </script>
    <script src="../assets/js/mobile-app.js"></script>
</body>
</html> 