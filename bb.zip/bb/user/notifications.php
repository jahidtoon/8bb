<?php
session_start();
require_once '../includes/db.php';
require_once '../includes/security.php';

// Check if user is logged in
if (!isAuthenticated()) {
    header('Location: login.php');
    exit;
}

// Get user ID
$userId = $_SESSION['user_id'];
$errors = [];
$success = '';

// Handle marking notifications as read/deleting
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['mark_read']) && isset($_POST['notification_id'])) {
        // Mark as read
        $notificationId = validateInt($_POST['notification_id']);
        
        $stmt = $db->prepare("UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?");
        $stmt->bind_param("ii", $notificationId, $userId);
        
        if ($stmt->execute()) {
            $success = "Notification marked as read.";
        } else {
            $errors[] = "Failed to update notification.";
        }
        $stmt->close();
    } elseif (isset($_POST['delete']) && isset($_POST['notification_id'])) {
        // Delete notification
        $notificationId = validateInt($_POST['notification_id']);
        
        $stmt = $db->prepare("DELETE FROM notifications WHERE id = ? AND user_id = ?");
        $stmt->bind_param("ii", $notificationId, $userId);
        
        if ($stmt->execute()) {
            $success = "Notification deleted.";
        } else {
            $errors[] = "Failed to delete notification.";
        }
        $stmt->close();
    } elseif (isset($_POST['mark_all_read'])) {
        // Mark all as read
        $stmt = $db->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ?");
        $stmt->bind_param("i", $userId);
        
        if ($stmt->execute()) {
            $success = "All notifications marked as read.";
        } else {
            $errors[] = "Failed to update notifications.";
        }
        $stmt->close();
    } elseif (isset($_POST['delete_all_read'])) {
        // Delete all read notifications
        $stmt = $db->prepare("DELETE FROM notifications WHERE user_id = ? AND is_read = 1");
        $stmt->bind_param("i", $userId);
        
        if ($stmt->execute()) {
            $success = "All read notifications deleted.";
        } else {
            $errors[] = "Failed to delete notifications.";
        }
        $stmt->close();
    }
}

// Get user's notifications
$query = "
    SELECT id, title, message, type, related_id, is_read, created_at
    FROM notifications
    WHERE user_id = ?
    ORDER BY created_at DESC
    LIMIT 50
";

$stmt = $db->prepare($query);
$stmt->bind_param("i", $userId);
$stmt->execute();
$notifications = $stmt->get_result();
$stmt->close();

// Count unread notifications
$stmt = $db->prepare("SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0");
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
$unreadCount = $result->fetch_assoc()['count'];
$stmt->close();

// Create table if it doesn't exist
function createNotificationsTable($db) {
    $query = "CREATE TABLE IF NOT EXISTS notifications (
        id INT(11) NOT NULL AUTO_INCREMENT,
        user_id INT(11) NOT NULL,
        title VARCHAR(255) NOT NULL,
        message TEXT NOT NULL,
        type VARCHAR(50) NOT NULL, 
        related_id INT(11) NULL DEFAULT NULL,
        is_read TINYINT(1) NOT NULL DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        INDEX (user_id),
        INDEX (is_read),
        INDEX (created_at)
    )";
    
    return $db->query($query);
}

// Create the table if it doesn't exist
createNotificationsTable($db);

// Function to get notification icon based on type
function getNotificationIcon($type) {
    switch ($type) {
        case 'generation_complete':
            return '<svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>';
        case 'system':
            return '<svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>';
        case 'points':
            return '<svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>';
        case 'error':
            return '<svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path></svg>';
        default:
            return '<svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"></path></svg>';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="View your AI Generator notifications">
    <title>Notifications - AI Generator</title>
    <link rel="preconnect" href="https://cdn.jsdelivr.net">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/main.css">
</head>
<body>
    <div class="min-h-screen">
        <!-- Navigation -->
        <nav class="glass-navbar shadow sticky top-0">
            <div class="container mx-auto px-4 max-w-7xl">
                <div class="flex justify-between h-14">
                    <div class="flex items-center">
                        <a href="../index.php" class="flex-shrink-0 flex items-center text-xl font-bold text-blue-400">
                            AI Generator
                        </a>
                    </div>
                    <div class="flex items-center">
                        <span class="text-gray-300 hidden sm:inline mr-4">Welcome, <?php echo htmlspecialchars($_SESSION['username'] ?? 'User'); ?></span>
                        <a href="profile.php" class="text-blue-300 hover:text-blue-100 mr-4">Profile</a>
                        <a href="favorites.php" class="text-blue-300 hover:text-blue-100 mr-4">Favorites</a>
                        <a href="history.php" class="text-blue-300 hover:text-blue-100 mr-4">Gallery</a>
                        <a href="logout.php" class="text-red-300 hover:text-red-100">Logout</a>
                    </div>
                </div>
            </div>
        </nav>
        
        <main class="container mx-auto px-4 py-6 max-w-7xl">
            <div class="flex justify-between items-center mb-6">
                <h1 class="text-2xl sm:text-3xl font-bold text-white">Notifications</h1>
                
                <div class="flex space-x-2">
                    <form method="POST" class="inline">
                        <button type="submit" name="mark_all_read" class="btn btn-sm btn-outline text-blue-300 border-blue-500 border-opacity-30 hover:bg-blue-500 hover:bg-opacity-20">
                            Mark All Read
                        </button>
                    </form>
                    
                    <form method="POST" class="inline">
                        <button type="submit" name="delete_all_read" class="btn btn-sm btn-outline text-red-300 border-red-500 border-opacity-30 hover:bg-red-500 hover:bg-opacity-20">
                            Delete Read
                        </button>
                    </form>
                </div>
            </div>
            
            <?php if (!empty($success)): ?>
                <div class="glass border border-green-500 border-opacity-30 text-green-300 px-4 py-3 mb-6 rounded relative">
                    <?php echo $success; ?>
                </div>
            <?php endif; ?>
            
            <?php if (!empty($errors)): ?>
                <div class="glass border border-red-500 border-opacity-30 text-red-300 px-4 py-3 mb-6 rounded relative">
                    <ul class="list-disc list-inside">
                        <?php foreach ($errors as $error): ?>
                            <li><?php echo htmlspecialchars($error); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>
            
            <div class="glass p-5 rounded-xl mb-6">
                <div class="flex items-center space-x-2">
                    <svg class="w-5 h-5 text-blue-300" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                    <p class="text-gray-300">
                        You have <span class="font-semibold text-blue-300"><?php echo $unreadCount; ?></span> unread notification<?php echo $unreadCount !== 1 ? 's' : ''; ?>.
                    </p>
                </div>
            </div>
            
            <?php if ($notifications->num_rows > 0): ?>
                <div class="space-y-4">
                    <?php while ($notification = $notifications->fetch_assoc()): ?>
                        <div class="glass p-5 rounded-xl <?php echo $notification['is_read'] ? 'opacity-70' : 'border-l-4 border-blue-500'; ?>">
                            <div class="flex items-start">
                                <div class="flex-shrink-0 <?php echo getNotificationTypeColor($notification['type']); ?>">
                                    <?php echo getNotificationIcon($notification['type']); ?>
                                </div>
                                
                                <div class="ml-4 flex-1">
                                    <div class="flex justify-between items-start">
                                        <h3 class="text-lg font-semibold text-white">
                                            <?php echo htmlspecialchars($notification['title']); ?>
                                        </h3>
                                        <span class="text-gray-400 text-xs">
                                            <?php echo getTimeAgo($notification['created_at']); ?>
                                        </span>
                                    </div>
                                    
                                    <p class="text-gray-300 mt-1">
                                        <?php echo htmlspecialchars($notification['message']); ?>
                                    </p>
                                    
                                    <?php if ($notification['type'] === 'generation_complete' && $notification['related_id']): ?>
                                        <div class="mt-3">
                                            <a href="history.php?id=<?php echo $notification['related_id']; ?>" class="text-blue-300 hover:text-blue-100 text-sm">
                                                View Generated Content
                                            </a>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="ml-4 flex-shrink-0 flex space-x-2">
                                    <?php if (!$notification['is_read']): ?>
                                        <form method="POST">
                                            <input type="hidden" name="notification_id" value="<?php echo $notification['id']; ?>">
                                            <button type="submit" name="mark_read" class="text-blue-300 hover:text-blue-100" title="Mark as read">
                                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                                                </svg>
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                    
                                    <form method="POST">
                                        <input type="hidden" name="notification_id" value="<?php echo $notification['id']; ?>">
                                        <button type="submit" name="delete" class="text-red-300 hover:text-red-100" title="Delete">
                                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                                            </svg>
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php else: ?>
                <div class="glass p-8 rounded-xl text-center">
                    <svg class="w-16 h-16 text-gray-500 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"></path>
                    </svg>
                    <h2 class="text-xl font-semibold text-gray-300 mb-2">No notifications</h2>
                    <p class="text-gray-400 mb-6">You don't have any notifications yet.</p>
                </div>
            <?php endif; ?>
        </main>
        
        <footer class="glass-footer py-4 mt-6">
            <div class="container mx-auto px-4 text-center text-gray-400 text-sm">
                <p>&copy; <?php echo date('Y'); ?> AI Generator. All rights reserved.</p>
            </div>
        </footer>
    </div>
</body>
</html>

<?php
// Helper function to get notification type color
function getNotificationTypeColor($type) {
    switch ($type) {
        case 'generation_complete':
            return 'text-green-300';
        case 'system':
            return 'text-blue-300';
        case 'points':
            return 'text-purple-300';
        case 'error':
            return 'text-red-300';
        default:
            return 'text-gray-300';
    }
}

// Helper function to get time ago
function getTimeAgo($datetime) {
    $time = strtotime($datetime);
    $now = time();
    $diff = $now - $time;
    
    if ($diff < 60) {
        return 'just now';
    } elseif ($diff < 3600) {
        $minutes = floor($diff / 60);
        return $minutes . ' minute' . ($minutes !== 1 ? 's' : '') . ' ago';
    } elseif ($diff < 86400) {
        $hours = floor($diff / 3600);
        return $hours . ' hour' . ($hours !== 1 ? 's' : '') . ' ago';
    } elseif ($diff < 604800) {
        $days = floor($diff / 86400);
        return $days . ' day' . ($days !== 1 ? 's' : '') . ' ago';
    } else {
        return date('M j, Y', $time);
    }
} 