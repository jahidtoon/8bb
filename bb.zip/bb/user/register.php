<?php
require_once '../includes/db.php';
session_start();

// Redirect if already logged in
if (isset($_SESSION['user_id'])) {
    header('Location: ../index.php');
    exit;
}

$errors = [];
$success = '';

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $email = trim($_POST['email'] ?? '');
    $full_name = trim($_POST['full_name'] ?? '');
    
    // Validate inputs
    if (empty($username)) {
        $errors[] = 'Username is required';
    } elseif (strlen($username) < 3) {
        $errors[] = 'Username must be at least 3 characters';
    } else {
        // Check if username already exists
        $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            $errors[] = 'Username already exists';
        }
        $stmt->close();
    }
    
    if (empty($password)) {
        $errors[] = 'Password is required';
    } elseif (strlen($password) < 6) {
        $errors[] = 'Password must be at least 6 characters';
    }
    
    if ($password !== $confirm_password) {
        $errors[] = 'Passwords do not match';
    }
    
    if (empty($email)) {
        $errors[] = 'Email is required';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Invalid email format';
    } else {
        // Check if email already exists
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            $errors[] = 'Email already exists';
        }
        $stmt->close();
    }
    
    // If no errors, create the user
    if (empty($errors)) {
        // Hash the password
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        
        // Insert user into database
        $stmt = $conn->prepare("INSERT INTO users (username, password, email, full_name, points) VALUES (?, ?, ?, ?, 100)");
        $stmt->bind_param("ssss", $username, $hashed_password, $email, $full_name);
        $success = $stmt->execute();
        
        if ($success) {
            $success = 'Registration successful! You can now <a href="login.php" class="text-blue-600 font-medium">login</a>.';
            // Clear form data on success
            $username = $email = $full_name = '';
        } else {
            $errors[] = 'Registration failed: ' . $stmt->error;
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
    <meta name="theme-color" content="#9c42f5">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="description" content="Create an account on ByteBrain AI Generator">
    <title>Register - ByteBrain</title>
    <link rel="preconnect" href="https://cdn.jsdelivr.net">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/main.css">
    <link rel="manifest" href="../manifest.json">
    <link rel="apple-touch-icon" href="../images/icon-192x192.png">
    <style>
        .register-container {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 1rem;
            background: radial-gradient(circle at 25% 25%, rgba(138, 43, 226, 0.1) 0%, transparent 50%),
                radial-gradient(circle at 75% 75%, rgba(25, 118, 210, 0.1) 0%, transparent 50%);
        }
        
        .register-form {
            width: 100%;
            max-width: 500px;
        }
    </style>
</head>
<body>
    <div class="register-container">
        <div class="register-form glass p-8 rounded-lg">
            <div>
                <div class="flex justify-center mb-4">
                    <span class="text-3xl font-bold text-gradient">ByteBrain</span>
                </div>
                <h1 class="mt-2 text-center text-3xl font-extrabold text-white">
                    Create an account
                </h1>
                <p class="mt-2 text-center text-sm text-gray-300">
                    Already have an account?
                    <a href="login.php" class="font-medium text-purple-300 hover:text-white">
                        Sign in
                    </a>
                </p>
            </div>
            
            <?php if (!empty($success)): ?>
                <div class="glass border border-green-500 border-opacity-30 text-green-300 px-4 py-3 mt-4 rounded relative">
                    <?php echo $success; ?>
                </div>
            <?php endif; ?>
            
            <?php if (!empty($errors)): ?>
                <div class="glass border border-red-500 border-opacity-30 text-red-300 px-4 py-3 mt-4 rounded relative">
                    <ul class="list-disc list-inside">
                        <?php foreach ($errors as $error): ?>
                            <li><?php echo htmlspecialchars($error); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>
            
            <form class="mt-6 space-y-4 glass-form" method="POST" novalidate>
                <div>
                    <label for="username" class="block text-sm font-medium text-gray-300 mb-1">Username</label>
                    <input id="username" name="username" type="text" required
                           class="appearance-none relative block w-full px-3 py-2 border border-opacity-20 rounded-md placeholder-gray-400 text-white focus:ring-purple-500 focus:border-purple-500 focus:z-10 sm:text-sm"
                           placeholder="Choose a unique username" value="<?php echo htmlspecialchars($username ?? ''); ?>">
                </div>
                
                <div>
                    <label for="email" class="block text-sm font-medium text-gray-300 mb-1">Email</label>
                    <input id="email" name="email" type="email" required
                           class="appearance-none relative block w-full px-3 py-2 border border-opacity-20 rounded-md placeholder-gray-400 text-white focus:ring-purple-500 focus:border-purple-500 focus:z-10 sm:text-sm"
                           placeholder="Your email address" value="<?php echo htmlspecialchars($email ?? ''); ?>">
                </div>
                
                <div>
                    <label for="full_name" class="block text-sm font-medium text-gray-300 mb-1">Full Name (Optional)</label>
                    <input id="full_name" name="full_name" type="text"
                           class="appearance-none relative block w-full px-3 py-2 border border-opacity-20 rounded-md placeholder-gray-400 text-white focus:ring-purple-500 focus:border-purple-500 focus:z-10 sm:text-sm"
                           placeholder="Your full name" value="<?php echo htmlspecialchars($full_name ?? ''); ?>">
                </div>
                
                <div>
                    <label for="password" class="block text-sm font-medium text-gray-300 mb-1">Password</label>
                    <input id="password" name="password" type="password" required
                           class="appearance-none relative block w-full px-3 py-2 border border-opacity-20 rounded-md placeholder-gray-400 text-white focus:ring-purple-500 focus:border-purple-500 focus:z-10 sm:text-sm"
                           placeholder="Create a password (min. 6 characters)">
                    <p class="mt-1 text-xs text-gray-400">Password must be at least 6 characters</p>
                </div>
                
                <div>
                    <label for="confirm_password" class="block text-sm font-medium text-gray-300 mb-1">Confirm Password</label>
                    <input id="confirm_password" name="confirm_password" type="password" required
                           class="appearance-none relative block w-full px-3 py-2 border border-opacity-20 rounded-md placeholder-gray-400 text-white focus:ring-purple-500 focus:border-purple-500 focus:z-10 sm:text-sm"
                           placeholder="Confirm your password">
                </div>

                <div class="mt-6">
                    <button type="submit"
                            class="group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white btn btn-primary">
                        Create Account
                    </button>
                </div>
                
                <div class="flex items-center justify-center">
                    <a href="../index.php" class="text-sm text-blue-300 hover:text-blue-100 flex items-center">
                        <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
                        </svg>
                        Back to Home
                    </a>
                </div>
            </form>
        </div>
    </div>
    <script src="../assets/js/mobile-app.js"></script>
</body>
</html> 