<?php
require_once '../includes/db.php';
session_start();

// Redirect if already logged in
if (isset($_SESSION['user_id'])) {
    header('Location: ../index.php');
    exit;
}

$error = '';

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    if (empty($username) || empty($password)) {
        $error = 'Please enter both username and password';
    } else {
        // Check if user exists
        $stmt = $conn->prepare("SELECT id, username, password, email, full_name, is_admin, status FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            
            // Verify password
            if (password_verify($password, $user['password'])) {
                // Check if account is active
                if ($user['status'] === 'disabled') {
                    $error = 'Your account has been disabled. Please contact the administrator.';
                } else {
                    // Set session variables
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['is_admin'] = $user['is_admin'];
                    
                    // Update last login time
                    $update_stmt = $conn->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
                    $update_stmt->bind_param("i", $user['id']);
                    $update_stmt->execute();
                    $update_stmt->close();
                    
                    // Redirect to home page
                    header('Location: ../index.php');
                    exit;
                }
            } else {
                $error = 'Invalid username or password';
            }
        } else {
            $error = 'Invalid username or password';
        }
        
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
    <meta name="theme-color" content="#9c42f5">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="description" content="Sign in to ByteBrain AI Generator">
    <title>Login - ByteBrain</title>
    <link rel="preconnect" href="https://cdn.jsdelivr.net">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/main.css">
    <link rel="manifest" href="../manifest.json">
    <link rel="apple-touch-icon" href="../images/icon-192x192.png">
    <style>
        .login-container {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 1rem;
            background: radial-gradient(circle at 25% 25%, rgba(138, 43, 226, 0.1) 0%, transparent 50%),
                radial-gradient(circle at 75% 75%, rgba(25, 118, 210, 0.1) 0%, transparent 50%);
        }
        
        .login-form {
            width: 100%;
            max-width: 400px;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-form glass p-8 rounded-lg">
            <div>
                <div class="flex justify-center mb-4">
                    <span class="text-3xl font-bold text-gradient">ByteBrain</span>
                </div>
                <h1 class="mt-2 text-center text-3xl font-extrabold text-white">
                    Sign in
                </h1>
                <p class="mt-2 text-center text-sm text-gray-300">
                    Or
                    <a href="register.php" class="font-medium text-purple-300 hover:text-white">
                        create a new account
                    </a>
                </p>
            </div>
            
            <?php if (!empty($error)): ?>
                <div class="glass border border-red-500 border-opacity-30 text-red-300 px-4 py-3 mt-4 rounded relative">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>
            
            <form class="mt-6 space-y-6 glass-form" method="POST">
                <div class="rounded-md -space-y-px">
                    <div class="mb-4">
                        <label for="username" class="block text-sm font-medium text-gray-300 mb-1">Username</label>
                        <input id="username" name="username" type="text" required
                               class="appearance-none relative block w-full px-3 py-2 border border-opacity-20 rounded-md placeholder-gray-400 text-white focus:ring-purple-500 focus:border-purple-500 focus:z-10 sm:text-sm"
                               placeholder="Enter your username">
                    </div>
                    <div>
                        <label for="password" class="block text-sm font-medium text-gray-300 mb-1">Password</label>
                        <input id="password" name="password" type="password" required
                               class="appearance-none relative block w-full px-3 py-2 border border-opacity-20 rounded-md placeholder-gray-400 text-white focus:ring-purple-500 focus:border-purple-500 focus:z-10 sm:text-sm"
                               placeholder="Enter your password">
                    </div>
                </div>

                <div>
                    <button type="submit"
                            class="group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white btn btn-primary">
                        Sign in
                    </button>
                </div>
                
                <div class="flex items-center justify-between mt-4">
                    <a href="../index.php" class="text-sm text-blue-300 hover:text-blue-100 flex items-center">
                        <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
                        </svg>
                        Back to Home
                    </a>
                    <a href="#" class="text-sm text-blue-300 hover:text-blue-100">
                        Forgot password?
                    </a>
                </div>
            </form>
        </div>
    </div>
    <script src="../assets/js/mobile-app.js"></script>
</body>
</html> 