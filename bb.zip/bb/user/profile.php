<?php
require_once '../includes/db.php';
session_start();

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Ensure username is set in session
if (!isset($_SESSION['username'])) {
    // Try to get username from database
    $username_stmt = $conn->prepare("SELECT username FROM users WHERE id = ?");
    $username_stmt->bind_param("i", $user_id);
    $username_stmt->execute();
    $username_result = $username_stmt->get_result();
    if ($username_row = $username_result->fetch_assoc()) {
        $_SESSION['username'] = $username_row['username'];
    } else {
        $_SESSION['username'] = 'User';
    }
    $username_stmt->close();
}

$errors = [];
$success = '';

// Get user info
$stmt = $conn->prepare("SELECT username, email, full_name, usage_count, usage_limit, created_at, points FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();

// If user not found, create a default empty user array
if (!$user) {
    $user = [
        'username' => 'Unknown',
        'email' => '',
        'full_name' => '',
        'usage_count' => 0,
        'usage_limit' => 0,
        'points' => 100,
        'created_at' => date('Y-m-d H:i:s')
    ];
    $errors[] = 'User data could not be found. Please contact an administrator.';
}

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'update_profile') {
        $email = trim($_POST['email'] ?? '');
        $full_name = trim($_POST['full_name'] ?? '');
        
        // Validate inputs
        if (empty($email)) {
            $errors[] = 'Email is required';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Invalid email format';
        } else if ($email !== $user['email']) {
            // Check if email already exists
            $stmt = $conn->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
            $stmt->bind_param("si", $email, $user_id);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($result->num_rows > 0) {
                $errors[] = 'Email already exists';
            }
            $stmt->close();
        }
        
        // If no errors, update the profile
        if (empty($errors)) {
            $stmt = $conn->prepare("UPDATE users SET email = ?, full_name = ? WHERE id = ?");
            $stmt->bind_param("ssi", $email, $full_name, $user_id);
            
            if ($stmt->execute()) {
                $success = 'Profile updated successfully';
                
                // Update local user data
                $user['email'] = $email;
                $user['full_name'] = $full_name;
            } else {
                $errors[] = 'Error updating profile: ' . $conn->error;
            }
            
            $stmt->close();
        }
    } elseif ($action === 'change_password') {
        $current_password = $_POST['current_password'] ?? '';
        $new_password = $_POST['new_password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';
        
        // Validate inputs
        if (empty($current_password)) {
            $errors[] = 'Current password is required';
        }
        
        if (empty($new_password)) {
            $errors[] = 'New password is required';
        } elseif (strlen($new_password) < 6) {
            $errors[] = 'New password must be at least 6 characters';
        }
        
        if ($new_password !== $confirm_password) {
            $errors[] = 'New passwords do not match';
        }
        
        // Verify current password
        if (empty($errors)) {
            $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $row = $result->fetch_assoc();
            $stmt->close();
            
            if (!$row || !password_verify($current_password, $row['password'])) {
                $errors[] = 'Current password is incorrect';
            }
        }
        
        // If no errors, update the password
        if (empty($errors)) {
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            
            $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
            $stmt->bind_param("si", $hashed_password, $user_id);
            
            if ($stmt->execute()) {
                $success = 'Password changed successfully';
            } else {
                $errors[] = 'Error changing password: ' . $conn->error;
            }
            
            $stmt->close();
        }
    }
}

// Get user's recent generations
$stmt = $conn->prepare("
    SELECT g.*, w.name as workflow_name, w.category
    FROM user_generations g
    JOIN workflows w ON g.workflow_id = w.id
    WHERE g.user_id = ?
    ORDER BY g.created_at DESC
    LIMIT 5
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$generations = $stmt->get_result();
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
    <meta name="theme-color" content="#9c42f5">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="description" content="User Profile - ByteBrain">
    <title>User Profile - ByteBrain</title>
    <link rel="preconnect" href="https://cdn.jsdelivr.net">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/main.css">
    <link rel="manifest" href="../manifest.json">
    <link rel="apple-touch-icon" href="../images/icon-192x192.png">
</head>
<body>
    <div class="min-h-screen">
        <header class="glass-navbar">
            <div class="container mx-auto px-4 max-w-7xl">
                <div class="flex justify-between h-16 items-center">
                    <div class="flex items-center">
                        <a href="../index.php" class="text-blue-400 text-2xl font-bold flex items-center">
                            <span class="text-gradient">ByteBrain</span>
                        </a>
                    </div>
                    <div class="flex items-center">
                        <span class="text-gray-300 hidden sm:inline mr-4">Welcome, <?php echo htmlspecialchars($_SESSION['username'] ?? 'User'); ?></span>
                        <a href="history.php" class="text-blue-300 hover:text-blue-100 px-4 py-2">Gallery</a>
                        <a href="logout.php" class="glass-btn text-white px-3 py-1 rounded-md">Logout</a>
                    </div>
                </div>
            </div>
        </header>
        
        <main class="container mx-auto px-4 py-8 max-w-7xl">
            <h1 class="text-3xl font-bold text-white mb-6">User Profile</h1>
            
            <?php if (!empty($success)): ?>
                <div class="glass border border-green-500 border-opacity-30 text-green-300 px-4 py-3 mb-6 rounded relative">
                    <?php echo $success; ?>
                </div>
            <?php endif; ?>
            
            <?php if (!empty($errors)): ?>
                <div class="glass border border-red-500 border-opacity-30 text-red-300 px-4 py-3 mb-6 rounded relative">
                    <ul class="list-disc list-inside">
                        <?php foreach ($errors as $error): ?>
                            <li><?php echo htmlspecialchars($error); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>
            
            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <!-- User Stats Card -->
                <div class="glass p-5 rounded-xl">
                    <h2 class="text-xl font-semibold text-white mb-4">User Details</h2>
                    
                    <div class="flex items-center justify-center mb-6">
                        <div class="w-24 h-24 rounded-full gradient-bg-1 flex items-center justify-center text-3xl text-white font-bold">
                            <?php echo strtoupper(substr($user['username'], 0, 1)); ?>
                        </div>
                    </div>
                    
                    <div class="text-center mb-4">
                        <h3 class="text-lg font-medium text-white"><?php echo htmlspecialchars($user['username']); ?></h3>
                        <?php if (!empty($user['full_name'])): ?>
                            <p class="text-gray-400"><?php echo htmlspecialchars($user['full_name']); ?></p>
                        <?php endif; ?>
                        <p class="text-gray-500 text-sm">Member since <?php echo date('M Y', strtotime($user['created_at'])); ?></p>
                    </div>
                    
                    <div class="border-t border-gray-700 pt-4">
                        <div class="mb-3">
                            <div class="flex justify-between mb-1">
                                <span class="text-gray-300">Points</span>
                                <span class="text-purple-300 font-medium"><?php echo number_format($user['points']); ?></span>
                            </div>
                            <div class="bg-gray-700 bg-opacity-50 rounded-full h-2">
                                <?php 
                                $point_percentage = min(100, ($user['points'] / 1000) * 100);
                                ?>
                                <div class="bg-purple-500 h-2 rounded-full" style="width: <?php echo $point_percentage; ?>%"></div>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <div class="flex justify-between mb-1">
                                <span class="text-gray-300">Usage</span>
                                <span class="text-blue-300 font-medium">
                                    <?php echo $user['usage_count']; ?>
                                    <?php if ($user['usage_limit'] > 0): ?>
                                        / <?php echo $user['usage_limit']; ?>
                                    <?php endif; ?>
                                </span>
                            </div>
                            <?php if ($user['usage_limit'] > 0): ?>
                                <div class="bg-gray-700 bg-opacity-50 rounded-full h-2">
                                    <?php 
                                    $usage_percentage = min(100, ($user['usage_count'] / $user['usage_limit']) * 100);
                                    ?>
                                    <div class="bg-blue-500 h-2 rounded-full" style="width: <?php echo $usage_percentage; ?>%"></div>
                                </div>
                            <?php else: ?>
                                <div class="text-xs text-gray-500">No usage limit set</div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Update Profile Form -->
                <div class="glass p-5 rounded-xl lg:col-span-2">
                    <h2 class="text-xl font-semibold text-white mb-4">Update Profile</h2>
                    
                    <form method="POST" class="glass-form space-y-4">
                        <div>
                            <label for="email" class="block text-sm font-medium text-gray-300 mb-1">Email</label>
                            <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required
                                   class="appearance-none relative block w-full px-3 py-2 border border-opacity-20 rounded-md placeholder-gray-400 text-white focus:ring-purple-500 focus:border-purple-500 focus:z-10 sm:text-sm">
                        </div>
                        
                        <div>
                            <label for="full_name" class="block text-sm font-medium text-gray-300 mb-1">Full Name (Optional)</label>
                            <input type="text" id="full_name" name="full_name" value="<?php echo htmlspecialchars($user['full_name']); ?>"
                                   class="appearance-none relative block w-full px-3 py-2 border border-opacity-20 rounded-md placeholder-gray-400 text-white focus:ring-purple-500 focus:border-purple-500 focus:z-10 sm:text-sm">
                        </div>
                        
                        <div class="pt-4">
                            <button type="submit" name="update_profile" class="btn btn-primary w-full">
                                Update Profile
                            </button>
                        </div>
                    </form>
                </div>

                <!-- Change Password Form -->
                <div class="glass p-5 rounded-xl lg:col-span-3">
                    <h2 class="text-xl font-semibold text-white mb-4">Change Password</h2>
                    
                    <form method="POST" class="glass-form space-y-4 max-w-lg mx-auto">
                        <div>
                            <label for="current_password" class="block text-sm font-medium text-gray-300 mb-1">Current Password</label>
                            <input type="password" id="current_password" name="current_password" required
                                   class="appearance-none relative block w-full px-3 py-2 border border-opacity-20 rounded-md placeholder-gray-400 text-white focus:ring-purple-500 focus:border-purple-500 focus:z-10 sm:text-sm">
                        </div>
                        
                        <div>
                            <label for="new_password" class="block text-sm font-medium text-gray-300 mb-1">New Password</label>
                            <input type="password" id="new_password" name="new_password" required
                                   class="appearance-none relative block w-full px-3 py-2 border border-opacity-20 rounded-md placeholder-gray-400 text-white focus:ring-purple-500 focus:border-purple-500 focus:z-10 sm:text-sm">
                            <p class="mt-1 text-xs text-gray-400">Password must be at least 6 characters</p>
                        </div>
                        
                        <div>
                            <label for="confirm_new_password" class="block text-sm font-medium text-gray-300 mb-1">Confirm New Password</label>
                            <input type="password" id="confirm_new_password" name="confirm_new_password" required
                                   class="appearance-none relative block w-full px-3 py-2 border border-opacity-20 rounded-md placeholder-gray-400 text-white focus:ring-purple-500 focus:border-purple-500 focus:z-10 sm:text-sm">
                        </div>
                        
                        <div class="pt-4">
                            <button type="submit" name="change_password" class="btn btn-primary w-full">
                                Change Password
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </main>
        
        <footer class="glass-footer py-4 mt-6">
            <div class="container mx-auto px-4 text-center text-gray-400 text-sm">
                <p>&copy; <?php echo date('Y'); ?> AI Generator. All rights reserved.</p>
            </div>
        </footer>
    </div>
    <script src="../assets/js/mobile-app.js"></script>
</body>
</html> 