<?php
session_start();
require_once '../includes/db.php';
require_once '../includes/security.php';

// Check if user is logged in
if (!isAuthenticated()) {
    header('Location: login.php');
    exit;
}

// Get user ID
$userId = $_SESSION['user_id'];
$errors = [];
$success = '';

// Handle adding/removing favorites
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_favorite']) && isset($_POST['workflow_id'])) {
        // Add to favorites
        $workflowId = validateInt($_POST['workflow_id']);
        
        // Check if already a favorite
        $checkStmt = $db->prepare("SELECT id FROM user_favorites WHERE user_id = ? AND workflow_id = ?");
        $checkStmt->bind_param("ii", $userId, $workflowId);
        $checkStmt->execute();
        $result = $checkStmt->get_result();
        
        if ($result->num_rows === 0) {
            // Not a favorite yet, add it
            $stmt = $db->prepare("INSERT INTO user_favorites (user_id, workflow_id, created_at) VALUES (?, ?, NOW())");
            $stmt->bind_param("ii", $userId, $workflowId);
            
            if ($stmt->execute()) {
                $success = "Workflow added to favorites!";
            } else {
                $errors[] = "Failed to add workflow to favorites.";
            }
            $stmt->close();
        } else {
            $errors[] = "This workflow is already in your favorites.";
        }
        $checkStmt->close();
    } elseif (isset($_POST['remove_favorite']) && isset($_POST['favorite_id'])) {
        // Remove from favorites
        $favoriteId = validateInt($_POST['favorite_id']);
        
        $stmt = $db->prepare("DELETE FROM user_favorites WHERE id = ? AND user_id = ?");
        $stmt->bind_param("ii", $favoriteId, $userId);
        
        if ($stmt->execute()) {
            $success = "Workflow removed from favorites.";
        } else {
            $errors[] = "Failed to remove workflow from favorites.";
        }
        $stmt->close();
    }
}

// Get user's favorites with workflow details
$query = "
    SELECT f.id as favorite_id, w.id, w.name, w.description, w.category, w.point_cost, f.created_at as favorited_at
    FROM user_favorites f
    JOIN workflows w ON f.workflow_id = w.id
    WHERE f.user_id = ?
    ORDER BY f.created_at DESC
";

$stmt = $db->prepare($query);
$stmt->bind_param("i", $userId);
$stmt->execute();
$favorites = $stmt->get_result();
$stmt->close();

// Create table if it doesn't exist
function createFavoritesTable($db) {
    $query = "CREATE TABLE IF NOT EXISTS user_favorites (
        id INT(11) NOT NULL AUTO_INCREMENT,
        user_id INT(11) NOT NULL,
        workflow_id INT(11) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY (user_id, workflow_id),
        INDEX (user_id),
        INDEX (workflow_id)
    )";
    
    return $db->query($query);
}

// Create the table if it doesn't exist
createFavoritesTable($db);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Manage your favorite AI Generator workflows">
    <title>My Favorites - AI Generator</title>
    <link rel="preconnect" href="https://cdn.jsdelivr.net">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/main.css">
</head>
<body>
    <div class="min-h-screen">
        <!-- Navigation -->
        <nav class="glass-navbar shadow sticky top-0">
            <div class="container mx-auto px-4 max-w-7xl">
                <div class="flex justify-between h-14">
                    <div class="flex items-center">
                        <a href="../index.php" class="flex-shrink-0 flex items-center text-xl font-bold text-blue-400">
                            AI Generator
                        </a>
                    </div>
                    <div class="flex items-center">
                        <span class="text-gray-300 hidden sm:inline mr-4">Welcome, <?php echo htmlspecialchars($_SESSION['username'] ?? 'User'); ?></span>
                        <a href="profile.php" class="text-blue-300 hover:text-blue-100 mr-4">Profile</a>
                        <a href="history.php" class="text-blue-300 hover:text-blue-100 mr-4">Gallery</a>
                        <a href="logout.php" class="text-red-300 hover:text-red-100">Logout</a>
                    </div>
                </div>
            </div>
        </nav>
        
        <main class="container mx-auto px-4 py-6 max-w-7xl">
            <h1 class="text-2xl sm:text-3xl font-bold text-white mb-6">My Favorite Workflows</h1>
            
            <?php if (!empty($success)): ?>
                <div class="glass border border-green-500 border-opacity-30 text-green-300 px-4 py-3 mb-6 rounded relative">
                    <?php echo $success; ?>
                </div>
            <?php endif; ?>
            
            <?php if (!empty($errors)): ?>
                <div class="glass border border-red-500 border-opacity-30 text-red-300 px-4 py-3 mb-6 rounded relative">
                    <ul class="list-disc list-inside">
                        <?php foreach ($errors as $error): ?>
                            <li><?php echo htmlspecialchars($error); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>
            
            <div class="glass p-5 rounded-xl mb-6">
                <p class="text-gray-300 mb-4">Save your favorite workflows for quick access. Favorites appear here and are highlighted on the home page.</p>
            </div>
            
            <?php if ($favorites->num_rows > 0): ?>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <?php while ($favorite = $favorites->fetch_assoc()): ?>
                        <div class="glass p-5 rounded-xl" style="content-visibility: auto;">
                            <div class="flex justify-between items-start mb-3">
                                <h3 class="text-lg font-semibold text-white"><?php echo htmlspecialchars($favorite['name']); ?></h3>
                                <span class="px-2 py-1 text-xs rounded bg-purple-500 bg-opacity-30 text-purple-300">
                                    <?php echo htmlspecialchars($favorite['category']); ?>
                                </span>
                            </div>
                            
                            <p class="text-gray-300 text-sm mb-4 h-12 overflow-hidden">
                                <?php echo htmlspecialchars(substr($favorite['description'], 0, 100)); ?>
                                <?php if (strlen($favorite['description']) > 100): ?>...<?php endif; ?>
                            </p>
                            
                            <div class="flex justify-between items-center mb-4">
                                <span class="text-gray-400 text-sm">
                                    <span class="text-purple-300"><?php echo $favorite['point_cost']; ?></span> points
                                </span>
                                <span class="text-gray-400 text-xs">
                                    Added <?php echo date('M j, Y', strtotime($favorite['favorited_at'])); ?>
                                </span>
                            </div>
                            
                            <div class="flex space-x-2">
                                <a href="../generate.php?id=<?php echo $favorite['id']; ?>" class="btn btn-primary flex-1 text-center text-sm py-2">
                                    Generate Now
                                </a>
                                
                                <form method="POST" class="flex-none">
                                    <input type="hidden" name="favorite_id" value="<?php echo $favorite['favorite_id']; ?>">
                                    <button type="submit" name="remove_favorite" class="btn btn-outline text-red-300 border-red-500 border-opacity-30 hover:bg-red-500 hover:bg-opacity-20 text-sm py-2">
                                        Remove
                                    </button>
                                </form>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php else: ?>
                <div class="glass p-8 rounded-xl text-center">
                    <svg class="w-16 h-16 text-gray-500 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"></path>
                    </svg>
                    <h2 class="text-xl font-semibold text-gray-300 mb-2">No favorites yet</h2>
                    <p class="text-gray-400 mb-6">You haven't added any workflows to your favorites yet.</p>
                    <a href="../index.php" class="btn btn-primary px-6">
                        Browse Workflows
                    </a>
                </div>
            <?php endif; ?>
        </main>
        
        <footer class="glass-footer py-4 mt-6">
            <div class="container mx-auto px-4 text-center text-gray-400 text-sm">
                <p>&copy; <?php echo date('Y'); ?> AI Generator. All rights reserved.</p>
            </div>
        </footer>
    </div>
</body>
</html> 