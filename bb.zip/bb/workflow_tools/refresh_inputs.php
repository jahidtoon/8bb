<?php
// This script refreshes all workflow inputs to ensure they're correctly displayed
require_once '../includes/db.php';
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');

echo "<h1>Workflow Input Refresh Tool</h1>";

// Define the standard inputs that should be in every workflow
$standardInputs = [
    'prompt' => [
        'type' => 'textarea',
        'default' => 'a beautiful photo of a landscape',
        'label' => 'Prompt'
    ],
    'negative_prompt' => [
        'type' => 'textarea',
        'default' => 'text, watermark, bad quality, blurry',
        'label' => 'Negative Prompt'
    ],
    'seed' => [
        'type' => 'number',
        'default' => '42',
        'label' => 'Seed'
    ],
    'steps' => [
        'type' => 'number',
        'default' => '20',
        'label' => 'Steps'
    ],
    'cfg' => [
        'type' => 'number',
        'default' => '7',
        'label' => 'CFG Scale'
    ],
    'sampler_name' => [
        'type' => 'select',
        'default' => 'euler',
        'label' => 'Sampler'
    ],
    'scheduler' => [
        'type' => 'select',
        'default' => 'normal',
        'label' => 'Scheduler'
    ],
    'width' => [
        'type' => 'number',
        'default' => '512',
        'label' => 'Width'
    ],
    'height' => [
        'type' => 'number',
        'default' => '512',
        'label' => 'Height'
    ]
];

// Get all workflows
$sql = "SELECT id, name, inputs FROM workflows";
$result = $conn->query($sql);
$updatedCount = 0;
$success = true;

echo "<h2>Processing Workflows</h2>";
echo "<ul>";

while ($row = $result->fetch_assoc()) {
    $workflowId = $row['id'];
    $workflowName = $row['name'];
    $currentInputs = json_decode($row['inputs'], true);
    
    if (!$currentInputs) {
        $currentInputs = [];
    }
    
    // Merge standard inputs with existing inputs
    // Make sure to completely replace any malformed inputs
    foreach ($standardInputs as $key => $input) {
        if (!isset($currentInputs[$key]) || !isset($currentInputs[$key]['type']) || !isset($currentInputs[$key]['default']) || !isset($currentInputs[$key]['label'])) {
            $currentInputs[$key] = $input;
        }
    }
    
    // Update the workflow with the refreshed inputs
    $updatedInputs = json_encode($currentInputs);
    $stmt = $conn->prepare("UPDATE workflows SET inputs = ? WHERE id = ?");
    $stmt->bind_param("si", $updatedInputs, $workflowId);
    
    if ($stmt->execute()) {
        $updatedCount++;
        echo "<li style='color:green;'>Updated workflow: " . htmlspecialchars($workflowName) . " (ID: $workflowId)</li>";
    } else {
        $success = false;
        echo "<li style='color:red;'>Failed to update: " . htmlspecialchars($workflowName) . " (ID: $workflowId) - " . $conn->error . "</li>";
    }
    
    $stmt->close();
}

echo "</ul>";

echo "<h2>Summary</h2>";
if ($success) {
    echo "<p style='color:green;'>Successfully refreshed inputs for $updatedCount workflows.</p>";
} else {
    echo "<p style='color:orange;'>Refreshed inputs for $updatedCount workflows, but some updates failed. See details above.</p>";
}

// Provide a test link
echo "<h2>Test a Workflow</h2>";
echo "<form method='get' action='../generate.php'>";
echo "<select name='id'>";
$result = $conn->query("SELECT id, name FROM workflows ORDER BY name");
while ($row = $result->fetch_assoc()) {
    echo "<option value='" . $row['id'] . "'>" . htmlspecialchars($row['name']) . " (ID: " . $row['id'] . ")</option>";
}
echo "</select>";
echo "&nbsp;<button type='submit' style='padding: 5px 10px; background: #4CAF50; color: white; border: none; border-radius: 4px;'>Test Workflow</button>";
echo "</form>";

// Add a link back to the homepage
echo "<p><a href='index.php'>Return to Homepage</a></p>";
?> 