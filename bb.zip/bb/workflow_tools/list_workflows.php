<?php
require_once '../includes/db.php';

// Check if text format is requested
$format = isset($_GET['format']) && $_GET['format'] === 'text' ? 'text' : 'html';

if ($format === 'text') {
    header('Content-Type: text/plain');
    
    echo "Available Workflows:\n";
    echo "-----------------\n\n";
    
    $sql = "SELECT id, name, category, point_cost FROM workflows ORDER BY category, name";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            echo "ID: " . $row['id'] . 
                 " | Name: " . $row['name'] . 
                 " | Category: " . $row['category'] . 
                 " | Points: " . $row['point_cost'] . "\n";
        }
    } else {
        echo "No workflows found\n";
    }
} else {
    // HTML format
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Workflow List</title>
        <link rel="stylesheet" href="../css/main.css">
        <style>
            .workflow-table {
                width: 100%;
                border-collapse: collapse;
                margin: 20px 0;
            }
            .workflow-table th, .workflow-table td {
                padding: 12px;
                border: 1px solid rgba(255, 255, 255, 0.1);
            }
            .workflow-table th {
                background-color: rgba(20, 20, 30, 0.8);
                text-align: left;
            }
            .workflow-table tr:nth-child(even) {
                background-color: rgba(40, 40, 50, 0.4);
            }
            .workflow-table tr:hover {
                background-color: rgba(60, 60, 70, 0.5);
            }
            .actions a {
                margin-right: 8px;
                padding: 4px 8px;
                background-color: #444;
                color: white;
                text-decoration: none;
                border-radius: 4px;
                font-size: 0.9em;
            }
            .actions a:hover {
                background-color: #555;
            }
            .back-link {
                margin-top: 20px;
                display: inline-block;
            }
        </style>
    </head>
    <body>
        <div class="container mx-auto p-5">
            <h1 class="text-3xl font-bold text-white mb-6">Available Workflows</h1>
            
            <p class="mb-4">
                <a href="?format=text" class="text-blue-400 hover:underline">View as plain text</a>
            </p>
            
            <table class="workflow-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Category</th>
                        <th>Points</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                $sql = "SELECT id, name, category, point_cost FROM workflows ORDER BY category, name";
                $result = $conn->query($sql);
                
                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row['id'] . "</td>";
                        echo "<td>" . htmlspecialchars($row['name']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['category']) . "</td>";
                        echo "<td>" . $row['point_cost'] . "</td>";
                        echo "<td class='actions'>";
                        echo "<a href='../generate.php?id=" . $row['id'] . "' target='_blank'>Generate</a>";
                        echo "<a href='check_workflow.php?id=" . $row['id'] . "'>Check</a>";
                        echo "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='5'>No workflows found</td></tr>";
                }
                ?>
                </tbody>
            </table>
            
            <a href="index.php" class="back-link text-blue-400 hover:underline">&laquo; Back to Workflow Tools</a>
        </div>
    </body>
    </html>
    <?php
}
?> 