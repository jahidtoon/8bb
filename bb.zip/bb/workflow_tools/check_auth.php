<?php
// This script simulates a login and then checks if generate.php works correctly
require_once '../includes/db.php';
session_start();

// Workflow ID to check
$workflow_id = isset($_GET['id']) ? (int)$_GET['id'] : 6;

// Check if the user is already logged in
if (isset($_SESSION['user_id'])) {
    $is_logged_in = true;
    $user_id = $_SESSION['user_id'];
} else {
    $is_logged_in = false;
    
    // Simulate login with the admin account (should exist in all installations)
    $_SESSION['user_id'] = 1;
    $_SESSION['username'] = 'admin';
    $_SESSION['is_admin'] = 1;
    $user_id = 1;
}

// Get the workflow details
$result = $conn->query("SELECT name, inputs, point_cost FROM workflows WHERE id = $workflow_id");
$workflow = $result->fetch_assoc();

// Initialize variables
$workflow_exists = true;
$user_data = null;
$inputs = null;

if (!$workflow) {
    $workflow_exists = false;
} else {
    // Get user data to check for restrictions
    $user_query = "SELECT usage_count, usage_limit, points FROM users WHERE id = ?";
    $stmt = $conn->prepare($user_query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $user_result = $stmt->get_result();
    $user_data = $user_result->fetch_assoc();
    $stmt->close();
    
    // Decode workflow inputs
    $inputs = json_decode($workflow['inputs'], true);
}

// Check standard inputs
$requiredInputs = ['prompt', 'negative_prompt', 'seed', 'steps', 'cfg', 'sampler_name', 'scheduler', 'width', 'height'];
$missingInputs = [];

if ($inputs) {
    foreach ($requiredInputs as $key) {
        if (!isset($inputs[$key])) {
            $missingInputs[] = $key;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Authentication Status Check</title>
    <link rel="stylesheet" href="../css/main.css">
    <style>
        .auth-card {
            background: rgba(30, 30, 40, 0.5);
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
        }
        .status-card {
            border-left: 4px solid;
            padding: 15px;
            margin-bottom: 15px;
        }
        .success-card {
            border-color: #69db7c;
            background-color: rgba(105, 219, 124, 0.1);
        }
        .warning-card {
            border-color: #ffd43b;
            background-color: rgba(255, 212, 59, 0.1);
        }
        .error-card {
            border-color: #ff6b6b;
            background-color: rgba(255, 107, 107, 0.1);
        }
        .info-card {
            border-color: #4dabf7;
            background-color: rgba(77, 171, 247, 0.1);
        }
        .status-list {
            list-style: none;
            padding: 0;
        }
        .status-list li {
            padding: 8px 0;
            display: flex;
            justify-content: space-between;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        .status-list li:last-child {
            border-bottom: none;
        }
        .status-label {
            font-weight: bold;
            margin-right: 20px;
            color: #bbb;
        }
        .status-value {
            text-align: right;
        }
        .action-buttons {
            display: flex;
            gap: 10px;
            margin-top: 20px;
        }
        .action-button {
            padding: 10px 15px;
            background-color: #444;
            color: white;
            text-decoration: none;
            border-radius: 4px;
        }
        .action-button:hover {
            background-color: #555;
        }
        .primary-button {
            background-color: #4dabf7;
        }
        .primary-button:hover {
            background-color: #3793d5;
        }
    </style>
</head>
<body>
    <div class="container mx-auto p-5">
        <h1 class="text-3xl font-bold text-white mb-6">Authentication Status Check</h1>
        
        <!-- Authentication Status -->
        <div class="auth-card">
            <h2 class="text-xl text-white mb-3">Authentication Status</h2>
            
            <?php if ($is_logged_in): ?>
                <div class="status-card success-card">
                    <p>User is already logged in with ID: <?php echo $user_id; ?></p>
                    <?php if (isset($_SESSION['is_admin']) && $_SESSION['is_admin']): ?>
                        <p class="mt-2">This user has admin privileges.</p>
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <div class="status-card info-card">
                    <p>User was not logged in. Login simulated with admin account (ID: 1)</p>
                </div>
            <?php endif; ?>
        </div>
        
        <!-- Workflow Check -->
        <?php if (!$workflow_exists): ?>
            <div class="auth-card">
                <h2 class="text-xl text-white mb-3">Workflow Access Check</h2>
                <div class="status-card error-card">
                    <p>Error: Workflow with ID <?php echo $workflow_id; ?> not found in the database.</p>
                </div>
                
                <div class="action-buttons">
                    <a href="list_workflows.php" class="action-button">View Available Workflows</a>
                    <a href="index.php" class="action-button">Back to Tools</a>
                </div>
            </div>
        <?php else: ?>
            <!-- Workflow Access -->
            <div class="auth-card">
                <h2 class="text-xl text-white mb-3">Workflow Access Check</h2>
                
                <ul class="status-list">
                    <li>
                        <span class="status-label">Workflow</span>
                        <span class="status-value"><?php echo htmlspecialchars($workflow['name']); ?> (ID: <?php echo $workflow_id; ?>)</span>
                    </li>
                    <li>
                        <span class="status-label">Required Points</span>
                        <span class="status-value"><?php echo $workflow['point_cost']; ?></span>
                    </li>
                    <li>
                        <span class="status-label">User Points Available</span>
                        <span class="status-value"><?php echo $user_data['points']; ?></span>
                    </li>
                    <li>
                        <span class="status-label">User Usage Count</span>
                        <span class="status-value"><?php echo $user_data['usage_count']; ?> / <?php echo $user_data['usage_limit']; ?></span>
                    </li>
                </ul>
                
                <?php
                // Check potential restrictions
                $usage_limit_reached = ($user_data['usage_limit'] > 0 && $user_data['usage_count'] >= $user_data['usage_limit']);
                $not_enough_points = ($workflow['point_cost'] > $user_data['points']);
                ?>
                
                <?php if ($usage_limit_reached): ?>
                    <div class="status-card error-card mt-4">
                        <p>Error: Usage limit reached. The user has reached their limit of <?php echo $user_data['usage_limit']; ?> generations.</p>
                    </div>
                <?php endif; ?>
                
                <?php if ($not_enough_points): ?>
                    <div class="status-card error-card mt-4">
                        <p>Error: Not enough points. The workflow requires <?php echo $workflow['point_cost']; ?> points but the user only has <?php echo $user_data['points']; ?> points.</p>
                    </div>
                <?php endif; ?>
                
                <?php if (!$usage_limit_reached && !$not_enough_points): ?>
                    <div class="status-card success-card mt-4">
                        <p>User has sufficient privileges to access this workflow.</p>
                    </div>
                <?php endif; ?>
            </div>
            
            <!-- Workflow Inputs Check -->
            <div class="auth-card">
                <h2 class="text-xl text-white mb-3">Workflow Inputs Check</h2>
                
                <?php if (empty($missingInputs)): ?>
                    <div class="status-card success-card">
                        <p>All required inputs are present in the workflow data.</p>
                    </div>
                    
                    <h3 class="text-lg text-white mt-4 mb-2">Input Fields in the Workflow:</h3>
                    <ul class="status-list">
                        <?php foreach ($inputs as $key => $input): ?>
                            <li>
                                <span class="status-label"><?php echo htmlspecialchars($key); ?></span>
                                <span class="status-value">
                                    <?php echo htmlspecialchars($input['label']); ?> 
                                    (Type: <?php echo htmlspecialchars($input['type']); ?>)
                                </span>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php else: ?>
                    <div class="status-card error-card">
                        <p>Missing required inputs: <?php echo implode(", ", $missingInputs); ?></p>
                        <p class="mt-2">Please run the workflow_inputs_fix.php script to fix this issue.</p>
                    </div>
                <?php endif; ?>
            </div>
            
            <!-- Action Buttons -->
            <div class="action-buttons">
                <a href="../generate.php?id=<?php echo $workflow_id; ?>" target="_blank" class="action-button primary-button">Open Generate Page</a>
                <a href="refresh_inputs.php?workflow_id=<?php echo $workflow_id; ?>" class="action-button">Fix Workflow Inputs</a>
                <a href="index.php" class="action-button">Back to Tools</a>
            </div>
        <?php endif; ?>
    </div>
</body>
</html> 