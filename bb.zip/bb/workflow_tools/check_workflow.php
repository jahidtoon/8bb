<?php
// This script checks what inputs are associated with a workflow
require_once '../includes/db.php';

// Get the workflow ID from the query string
$id = isset($_GET['id']) ? (int)$_GET['id'] : 6;

// Format parameter (text or html)
$format = isset($_GET['format']) && $_GET['format'] === 'text' ? 'text' : 'html';

// Get the workflow details
$result = $conn->query("SELECT name, inputs FROM workflows WHERE id = $id");
$workflow = $result->fetch_assoc();

if (!$workflow) {
    if ($format === 'text') {
        echo "Workflow not found";
    } else {
        echo "<h2>Error: Workflow not found</h2>";
        echo "<p>The workflow with ID $id does not exist in the database.</p>";
        echo '<p><a href="index.php">&laquo; Back to Workflow Tools</a></p>';
    }
    exit;
}

// Define the list of standard inputs to check
$requiredInputs = [
    'prompt', 'negative_prompt', 'seed', 'steps', 'cfg', 
    'sampler_name', 'scheduler', 'width', 'height'
];

// Decode the inputs
$inputs = json_decode($workflow['inputs'], true);
$jsonError = json_last_error() !== JSON_ERROR_NONE;

if ($format === 'text') {
    // Plain text output
    echo "Workflow: " . $workflow['name'] . " (ID: $id)\n\n";
    
    if ($jsonError) {
        echo "Error parsing JSON: " . json_last_error_msg() . "\n";
    } else {
        // Check each input
        foreach ($requiredInputs as $key) {
            if (isset($inputs[$key])) {
                echo "$key: Present - " . $inputs[$key]['default'] . "\n";
            } else {
                echo "$key: MISSING\n";
            }
        }
    }
} else {
    // HTML output
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Workflow Check: <?php echo htmlspecialchars($workflow['name']); ?></title>
        <link rel="stylesheet" href="../css/main.css">
        <style>
            .input-table {
                width: 100%;
                border-collapse: collapse;
                margin: 20px 0;
            }
            .input-table th, .input-table td {
                padding: 10px;
                border: 1px solid rgba(255, 255, 255, 0.1);
            }
            .input-table th {
                background-color: rgba(20, 20, 30, 0.8);
                text-align: left;
            }
            .missing {
                color: #ff6b6b;
                font-weight: bold;
            }
            .present {
                color: #69db7c;
            }
            .workflow-json {
                background-color: rgba(30, 30, 40, 0.5);
                border-radius: 4px;
                padding: 15px;
                overflow: auto;
                max-height: 300px;
                font-family: monospace;
                color: #ddd;
                white-space: pre-wrap;
            }
            .actions {
                margin-top: 20px;
                display: flex;
                gap: 10px;
            }
            .actions a {
                padding: 8px 16px;
                background-color: #444;
                color: white;
                text-decoration: none;
                border-radius: 4px;
            }
            .actions a:hover {
                background-color: #555;
            }
        </style>
    </head>
    <body>
        <div class="container mx-auto p-5">
            <h1 class="text-3xl font-bold text-white mb-4">Workflow Check</h1>
            <h2 class="text-2xl text-purple-400 mb-6"><?php echo htmlspecialchars($workflow['name']); ?> (ID: <?php echo $id; ?>)</h2>
            
            <p class="mb-2">
                <a href="?id=<?php echo $id; ?>&format=text" class="text-blue-400 hover:underline">View as plain text</a>
            </p>
            
            <?php if ($jsonError): ?>
                <div class="bg-red-900 bg-opacity-30 p-4 rounded mb-6">
                    <h3 class="text-xl text-red-400 mb-2">JSON Error</h3>
                    <p>There was an error parsing the workflow inputs: <?php echo json_last_error_msg(); ?></p>
                </div>
            <?php else: ?>
                <h3 class="text-xl text-white mb-4">Required Inputs</h3>
                <table class="input-table">
                    <thead>
                        <tr>
                            <th>Input Name</th>
                            <th>Status</th>
                            <th>Label</th>
                            <th>Type</th>
                            <th>Default Value</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($requiredInputs as $key): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($key); ?></td>
                                <?php if (isset($inputs[$key])): ?>
                                    <td class="present">Present</td>
                                    <td><?php echo htmlspecialchars($inputs[$key]['label']); ?></td>
                                    <td><?php echo htmlspecialchars($inputs[$key]['type']); ?></td>
                                    <td><?php echo htmlspecialchars($inputs[$key]['default']); ?></td>
                                <?php else: ?>
                                    <td class="missing">MISSING</td>
                                    <td>-</td>
                                    <td>-</td>
                                    <td>-</td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                
                <h3 class="text-xl text-white mt-6 mb-3">Raw JSON</h3>
                <div class="workflow-json"><?php echo htmlspecialchars($workflow['inputs']); ?></div>
            <?php endif; ?>
            
            <div class="actions">
                <a href="index.php">&laquo; Back to Workflow Tools</a>
                <a href="../generate.php?id=<?php echo $id; ?>" target="_blank">Open in Generator</a>
                <a href="refresh_inputs.php?workflow_id=<?php echo $id; ?>">Fix Workflow Inputs</a>
            </div>
        </div>
    </body>
    </html>
    <?php
}
?> 