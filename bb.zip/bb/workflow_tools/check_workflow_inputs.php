<?php
require_once '../includes/db.php';

// Start output buffering
ob_start();

// Get the workflow inputs
$id = isset($_GET['id']) ? (int)$_GET['id'] : 6; // Workflow ID to check
$result = $conn->query("SELECT name, inputs FROM workflows WHERE id = $id");
$workflow = $result->fetch_assoc();

if (!$workflow) {
    echo "Workflow not found";
    exit;
}

echo "Workflow Name: " . $workflow['name'] . "\n\n";
echo "Raw Inputs JSON:\n" . $workflow['inputs'] . "\n\n";

// Decode and display in a formatted way
$inputs = json_decode($workflow['inputs'], true);
if ($inputs) {
    echo "Input Fields:\n";
    foreach ($inputs as $key => $input) {
        echo "- $key: " . $input['label'] . " (Type: " . $input['type'] . ", Default: " . $input['default'] . ")\n";
    }
} else {
    echo "Error decoding inputs JSON";
}

// Get the content from the output buffer
$content = ob_get_clean();

// Save to a file
file_put_contents('workflow_inputs_check.txt', $content);

echo "Check completed. Results saved to workflow_tools/workflow_inputs_check.txt";
?> 