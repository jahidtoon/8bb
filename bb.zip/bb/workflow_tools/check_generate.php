<?php
// This script checks if a workflow's inputs are correctly loaded in the database
// and also verifies that they are being correctly displayed on the generate.php page

require_once '../includes/db.php';

// Check a specific workflow
$workflow_id = isset($_GET['id']) ? (int)$_GET['id'] : 6;

// Step 1: Get the workflow details from the database
$sql = "SELECT id, name, inputs FROM workflows WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $workflow_id);
$stmt->execute();
$result = $stmt->get_result();
$workflow = $result->fetch_assoc();

if (!$workflow) {
    echo "Workflow not found in the database.";
    exit;
}

// Step 2: Decode the inputs JSON
$inputs = json_decode($workflow['inputs'], true);
if (!$inputs) {
    echo "Error decoding inputs JSON for workflow '{$workflow['name']}' (ID: {$workflow['id']})";
    exit;
}

echo "Workflow '{$workflow['name']}' (ID: {$workflow['id']}) has the following inputs:<br>";
echo "<ul>";
foreach ($inputs as $key => $input) {
    echo "<li>{$input['label']} ({$key}): Type: {$input['type']}, Default: {$input['default']}</li>";
}
echo "</ul>";

// Step 3: Check if all required inputs are present
$standard_inputs = ['prompt', 'negative_prompt', 'seed', 'steps', 'cfg', 'sampler_name', 'scheduler', 'width', 'height'];
$missing_inputs = [];

foreach ($standard_inputs as $key) {
    if (!isset($inputs[$key])) {
        $missing_inputs[] = $key;
    }
}

if (count($missing_inputs) > 0) {
    echo "<br>WARNING: This workflow is missing the following standard inputs: " . implode(", ", $missing_inputs);
    echo "<br>Please run the workflow_inputs_fix.php script to fix this issue.";
} else {
    echo "<br>This workflow has all standard inputs correctly configured.";
    echo "<br>If they are not appearing on the generate.php page, there might be an issue with the page's code.";
}

// Provide a link back to the tools index
echo '<br><br><a href="index.php">&laquo; Back to Workflow Tools</a>';
?> 