<?php
// This script checks if there's an issue with the display of inputs in the generate.php file
require_once '../includes/db.php';

// Define all the potential issues we might need to fix
$issues = [];

// 1. Check if the generate.php file exists
if (!file_exists('../generate.php')) {
    $issues[] = "generate.php file not found";
}

// 2. Read the generate.php file content
$generateCode = file_get_contents('../generate.php');

// 3. Check if the inputs are decoded correctly
$inputsDecodeExists = strpos($generateCode, '$inputs = json_decode') !== false;
if (!$inputsDecodeExists) {
    $issues[] = "Inputs JSON decoding code not found in generate.php";
}

// 4. Check if there's a foreach loop for inputs
$foreachExists = strpos($generateCode, 'foreach ($inputs as') !== false;
if (!$foreachExists) {
    $issues[] = "foreach loop for inputs not found in generate.php";
}

// 5. Check if inputs are properly retrieved from the database
// Get line where inputs are decoded
$pattern = '/\$inputs\s*=\s*json_decode\s*\(\s*\$workflow\[\s*[\'"]inputs[\'"]\s*\]\s*,\s*true\s*\)\s*;/';
preg_match($pattern, $generateCode, $matches, PREG_OFFSET_CAPTURE);

if (empty($matches)) {
    $issues[] = "Could not find the exact pattern for JSON decoding in generate.php";
}

// 6. Check if inputs are rendered in a form
$formExists = strpos($generateCode, '<form id="generateForm"') !== false;
if (!$formExists) {
    $issues[] = "Form element for inputs not found in generate.php";
}

// Report the findings
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generate.php Display Diagnostic</title>
    <link rel="stylesheet" href="../css/main.css">
    <style>
        .diagnostic-card {
            background: rgba(30, 30, 40, 0.5);
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
        }
        .issue-list {
            margin: 15px 0;
            padding-left: 20px;
        }
        .issue-item {
            color: #ff6b6b;
            margin-bottom: 8px;
        }
        .success-message {
            color: #69db7c;
            font-weight: bold;
        }
        .warning-message {
            color: #ffd43b;
        }
        .fix-button {
            display: inline-block;
            padding: 10px 16px;
            background-color: #4CAF50;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            margin-top: 10px;
        }
        .fix-button:hover {
            background-color: #3e8e41;
        }
        .test-links {
            margin-top: 30px;
        }
        .test-list {
            list-style: none;
            padding: 0;
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 10px;
        }
        .test-item a {
            display: block;
            padding: 10px;
            background-color: rgba(60, 60, 70, 0.5);
            color: white;
            text-decoration: none;
            border-radius: 4px;
        }
        .test-item a:hover {
            background-color: rgba(80, 80, 90, 0.5);
        }
    </style>
</head>
<body>
    <div class="container mx-auto p-5">
        <h1 class="text-3xl font-bold text-white mb-6">Generate.php Display Diagnostic</h1>
        
        <div class="diagnostic-card">
            <?php if (empty($issues)): ?>
                <p class="success-message">No issues found in the generate.php file structure.</p>
                <p>If inputs are still not displaying properly, please verify the database contents for your workflows.</p>
                <p class="mt-4">
                    <a href="refresh_inputs.php" class="fix-button">Run Workflow Input Refresh</a>
                </p>
            <?php else: ?>
                <p class="warning-message">Found <?php echo count($issues); ?> potential issues with generate.php:</p>
                <ul class="issue-list">
                    <?php foreach ($issues as $issue): ?>
                        <li class="issue-item"><?php echo htmlspecialchars($issue); ?></li>
                    <?php endforeach; ?>
                </ul>
                
                <p class="mt-4">Consider running the workflow_inputs_fix.php script to fix workflow input data:</p>
                <a href="../admin/workflow_inputs_fix.php" class="fix-button">Run Workflow Input Fix</a>
            <?php endif; ?>
        </div>
        
        <div class="test-links">
            <h2 class="text-2xl text-white mb-4">Test Specific Workflows</h2>
            <p class="mb-3">Select a workflow to test:</p>
            
            <ul class="test-list">
                <?php
                $result = $conn->query("SELECT id, name FROM workflows ORDER BY id");
                while ($row = $result->fetch_assoc()): 
                ?>
                    <li class="test-item">
                        <a href="../generate.php?id=<?php echo $row['id']; ?>" target="_blank">
                            <?php echo htmlspecialchars($row['name']); ?> (ID: <?php echo $row['id']; ?>)
                        </a>
                    </li>
                <?php endwhile; ?>
            </ul>
        </div>
        
        <div class="mt-6">
            <a href="index.php" class="text-blue-400 hover:underline">&laquo; Back to Workflow Tools</a>
        </div>
    </div>
</body>
</html> 