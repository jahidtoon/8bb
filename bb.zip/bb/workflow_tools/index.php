<?php
// Workflow Tools Index page
require_once '../includes/db.php';

// Check if user is admin
session_start();
$is_admin = isset($_SESSION['is_admin']) && $_SESSION['is_admin'] === 1;

// Get all workflow tools
$tools = [
    [
        'name' => 'List Workflows',
        'file' => 'list_workflows.php',
        'description' => 'List all workflows in the system'
    ],
    [
        'name' => 'Check Workflow',
        'file' => 'check_workflow.php',
        'description' => 'Check a specific workflow configuration' 
    ],
    [
        'name' => 'Refresh Inputs',
        'file' => 'refresh_inputs.php',
        'description' => 'Update all workflows with standard inputs'
    ],
    [
        'name' => 'Check Generate Display',
        'file' => 'fix_generate_display.php',
        'description' => 'Diagnose generate.php display issues'
    ],
    [
        'name' => 'Authentication Check',
        'file' => 'check_auth.php',
        'description' => 'Test authentication for workflow access'
    ],
    [
        'name' => 'Check Workflow Inputs',
        'file' => 'check_workflow_inputs.php',
        'description' => 'Examine input configuration for a workflow'
    ],
    [
        'name' => 'Check Generate',
        'file' => 'check_generate.php',
        'description' => 'Check if a workflow is configured properly' 
    ]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Workflow Tools</title>
    <link rel="stylesheet" href="../css/main.css">
    <style>
        .tool-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        .tool-card {
            background: rgba(30, 30, 40, 0.5);
            border-radius: 10px;
            padding: 20px;
            border: 1px solid rgba(255, 255, 255, 0.1);
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .tool-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
        }
        .tool-card h3 {
            margin-top: 0;
            color: #9c42f5;
        }
        .tool-card p {
            margin-bottom: 15px;
            color: #ccc;
        }
        .back-button {
            margin-top: 20px;
            display: inline-block;
            text-decoration: none;
            padding: 8px 16px;
            background-color: #333;
            color: white;
            border-radius: 4px;
        }
    </style>
</head>
<body>
    <div class="container mx-auto p-5">
        <h1 class="text-3xl font-bold text-center text-white mb-6">Workflow Management Tools</h1>
        
        <?php if (!$is_admin): ?>
        <div class="glass p-4 mb-6 border-l-4 border-yellow-500 border-opacity-50 text-yellow-200">
            <p class="font-bold">Admin Access Recommended</p>
            <p>These tools are designed for administrators. Some features may not work without admin privileges.</p>
        </div>
        <?php endif; ?>
        
        <div class="tool-grid">
            <?php foreach ($tools as $tool): ?>
            <div class="tool-card">
                <h3><?php echo htmlspecialchars($tool['name']); ?></h3>
                <p><?php echo htmlspecialchars($tool['description']); ?></p>
                <a href="<?php echo htmlspecialchars($tool['file']); ?>" class="btn btn-primary">Open Tool</a>
            </div>
            <?php endforeach; ?>
        </div>
        
        <div class="text-center mt-6">
            <a href="../index.php" class="back-button">Back to Main Site</a>
        </div>
    </div>
</body>
</html> 