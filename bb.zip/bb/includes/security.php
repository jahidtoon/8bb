<?php
/**
 * Security Functions
 * 
 * This file contains functions to help secure the website
 * and prevent unauthorized access to API endpoints.
 */

/**
 * Check if the request is authenticated
 * 
 * @param string $requiredRole The role required (optional, 'user' or 'admin')
 * @return bool Whether the user is authenticated with the required role
 */
function isAuthenticated($requiredRole = 'user') {
    // Make sure a session is active
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    
    // Check if user is logged in
    if (!isset($_SESSION['user_id'])) {
        return false;
    }
    
    // If admin role is required
    if ($requiredRole === 'admin' && (!isset($_SESSION['is_admin']) || !$_SESSION['is_admin'])) {
        return false;
    }
    
    return true;
}

/**
 * Validate and sanitize an integer input
 * 
 * @param mixed $input The input to validate
 * @param int $default Default value if validation fails
 * @return int Sanitized integer
 */
function validateInt($input, $default = 0) {
    if (!isset($input) || !is_numeric($input)) {
        return $default;
    }
    
    return (int)$input;
}

/**
 * Validate and sanitize a string input
 * 
 * @param mixed $input The input to validate
 * @param string $default Default value if validation fails
 * @return string Sanitized string
 */
function validateString($input, $default = '') {
    if (!isset($input) || !is_string($input)) {
        return $default;
    }
    
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

/**
 * Generate a random token for CSRF protection
 * 
 * @return string A random token
 */
function generateToken() {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    
    return $_SESSION['csrf_token'];
}

/**
 * Verify CSRF token
 * 
 * @param string $token The token to verify
 * @return bool Whether the token is valid
 */
function verifyToken($token) {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    
    if (!isset($_SESSION['csrf_token']) || $token !== $_SESSION['csrf_token']) {
        return false;
    }
    
    return true;
}

/**
 * Restrict API access to logged-in users
 * Exits script with error if not authenticated
 */
function requireAuthentication() {
    if (!isAuthenticated()) {
        header('Content-Type: application/json');
        echo json_encode([
            'error' => 'Authentication required',
            'code' => 401
        ]);
        exit;
    }
}

/**
 * Restrict access to admins only
 * Exits script with error if not admin
 */
function requireAdmin() {
    if (!isAuthenticated('admin')) {
        header('Content-Type: application/json');
        echo json_encode([
            'error' => 'Admin access required',
            'code' => 403
        ]);
        exit;
    }
}
?> 