<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'ai_website_db');
define('COMFYUI_URL', 'http://127.0.0.1:8188');
define('UPLOAD_DIR', __DIR__ . '/../uploads/');
?> 