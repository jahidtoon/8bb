<?php
/**
 * API Rate Limiter
 * 
 * This file provides functionality to limit API requests and prevent abuse
 * It uses a database table to track API calls by IP and user ID
 */

// Include database connection
require_once 'db.php';

class ApiLimiter {
    private $db;
    private $userId;
    private $ipAddress;
    
    // Default limits
    private $maxRequestsPerMinute = 10;
    private $maxRequestsPerHour = 60;
    private $maxRequestsPerDay = 300;
    
    /**
     * Constructor
     * 
     * @param mysqli $db Database connection
     * @param int $userId User ID (optional)
     */
    public function __construct($db, $userId = null) {
        $this->db = $db;
        $this->userId = $userId;
        $this->ipAddress = $_SERVER['REMOTE_ADDR'];
        
        // Ensure the API logs table exists
        $this->createTableIfNotExists();
    }
    
    /**
     * Set custom rate limits
     * 
     * @param int $perMinute Requests per minute
     * @param int $perHour Requests per hour
     * @param int $perDay Requests per day
     */
    public function setLimits($perMinute = null, $perHour = null, $perDay = null) {
        if ($perMinute !== null) $this->maxRequestsPerMinute = $perMinute;
        if ($perHour !== null) $this->maxRequestsPerHour = $perHour;
        if ($perDay !== null) $this->maxRequestsPerDay = $perDay;
    }
    
    /**
     * Check if the current user/IP has exceeded rate limits
     * 
     * @param string $endpoint The API endpoint being accessed (optional)
     * @return array ['allowed' => bool, 'message' => string]
     */
    public function checkLimits($endpoint = null) {
        // Log the request
        $this->logRequest($endpoint);
        
        // Check minute limit
        $minuteCount = $this->getRequestCount(60);
        if ($minuteCount > $this->maxRequestsPerMinute) {
            return [
                'allowed' => false,
                'message' => "Rate limit exceeded. Maximum {$this->maxRequestsPerMinute} requests per minute allowed."
            ];
        }
        
        // Check hour limit
        $hourCount = $this->getRequestCount(3600);
        if ($hourCount > $this->maxRequestsPerHour) {
            return [
                'allowed' => false,
                'message' => "Rate limit exceeded. Maximum {$this->maxRequestsPerHour} requests per hour allowed."
            ];
        }
        
        // Check day limit
        $dayCount = $this->getRequestCount(86400);
        if ($dayCount > $this->maxRequestsPerDay) {
            return [
                'allowed' => false,
                'message' => "Rate limit exceeded. Maximum {$this->maxRequestsPerDay} requests per day allowed."
            ];
        }
        
        return ['allowed' => true, 'message' => 'Request allowed'];
    }
    
    /**
     * Log an API request to the database
     * 
     * @param string $endpoint The API endpoint being accessed
     */
    private function logRequest($endpoint = null) {
        $stmt = $this->db->prepare("INSERT INTO api_logs (user_id, ip_address, endpoint) VALUES (?, ?, ?)");
        $stmt->bind_param("iss", $this->userId, $this->ipAddress, $endpoint);
        $stmt->execute();
        $stmt->close();
    }
    
    /**
     * Get the number of requests in a time period
     * 
     * @param int $seconds Time period in seconds
     * @return int Number of requests
     */
    private function getRequestCount($seconds) {
        $timeAgo = date('Y-m-d H:i:s', time() - $seconds);
        
        if ($this->userId) {
            // If user is logged in, count by user ID
            $stmt = $this->db->prepare("SELECT COUNT(*) as count FROM api_logs WHERE user_id = ? AND created_at > ?");
            $stmt->bind_param("is", $this->userId, $timeAgo);
        } else {
            // If not logged in, count by IP
            $stmt = $this->db->prepare("SELECT COUNT(*) as count FROM api_logs WHERE ip_address = ? AND created_at > ?");
            $stmt->bind_param("ss", $this->ipAddress, $timeAgo);
        }
        
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        $stmt->close();
        
        return $row['count'];
    }
    
    /**
     * Create the api_logs table if it doesn't exist
     */
    private function createTableIfNotExists() {
        $query = "CREATE TABLE IF NOT EXISTS api_logs (
            id INT(11) NOT NULL AUTO_INCREMENT,
            user_id INT(11) NULL DEFAULT NULL,
            ip_address VARCHAR(45) NOT NULL,
            endpoint VARCHAR(255) NULL DEFAULT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            INDEX (user_id),
            INDEX (ip_address),
            INDEX (created_at)
        )";
        
        $this->db->query($query);
    }
    
    /**
     * Clean up old logs (can be run via cron)
     * 
     * @param int $days Number of days to keep logs
     */
    public function cleanupOldLogs($days = 30) {
        $cutoff = date('Y-m-d H:i:s', time() - ($days * 86400));
        
        $stmt = $this->db->prepare("DELETE FROM api_logs WHERE created_at < ?");
        $stmt->bind_param("s", $cutoff);
        $stmt->execute();
        
        return $stmt->affected_rows;
    }
}

/**
 * Helper function to create a new ApiLimiter instance
 * 
 * @param mysqli $db Database connection
 * @param int $userId User ID (optional)
 * @return ApiLimiter
 */
function createApiLimiter($db, $userId = null) {
    return new ApiLimiter($db, $userId);
} 