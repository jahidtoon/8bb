/**
 * Mobile App-like Experience for ByteBrain
 * 
 * This script handles mobile-specific behaviors to create
 * a more app-like experience when viewed on phones.
 */

document.addEventListener('DOMContentLoaded', function() {
    if (window.innerWidth <= 768) {
        // Create mobile bottom nav if it doesn't exist
        if (!document.querySelector('.mobile-bottom-nav')) {
            createMobileBottomNav();
        }
        
        // Handle navbar hiding on scroll
        let lastScrollTop = 0;
        const navbar = document.querySelector('.glass-navbar');
        
        if (navbar) {
            window.addEventListener('scroll', function() {
                let scrollTop = window.pageYOffset || document.documentElement.scrollTop;
                
                if (scrollTop > lastScrollTop && scrollTop > 60) {
                    // Scrolling down - hide navbar
                    navbar.classList.add('navbar-hidden');
                } else {
                    // Scrolling up - show navbar
                    navbar.classList.remove('navbar-hidden');
                }
                
                lastScrollTop = scrollTop;
            }, { passive: true });
        }
        
        // Add active state to buttons for better touch feedback
        const buttons = document.querySelectorAll('.btn, .glass-btn');
        buttons.forEach(button => {
            button.addEventListener('touchstart', function() {
                this.classList.add('btn-active');
            }, { passive: true });
            
            button.addEventListener('touchend', function() {
                this.classList.remove('btn-active');
            }, { passive: true });
        });
        
        // Make status bar match theme color on iOS
        const metaThemeColor = document.querySelector('meta[name="theme-color"]');
        if (!metaThemeColor) {
            const meta = document.createElement('meta');
            meta.name = 'theme-color';
            meta.content = '#9c42f5';
            document.head.appendChild(meta);
        }
        
        // Add viewport-fit=cover for notched phones
        const metaViewport = document.querySelector('meta[name="viewport"]');
        if (metaViewport) {
            if (!metaViewport.content.includes('viewport-fit=cover')) {
                metaViewport.content += ', viewport-fit=cover';
            }
        }
    }
});

/**
 * Creates the mobile bottom navigation bar
 */
function createMobileBottomNav() {
    const nav = document.createElement('div');
    nav.className = 'mobile-bottom-nav';
    
    // Determine current page to highlight active item
    const currentPath = window.location.pathname;
    const isHome = currentPath.endsWith('index.php') || currentPath.endsWith('/');
    const isProfile = currentPath.includes('profile.php');
    const isHistory = currentPath.includes('history.php');
    const isGenerate = currentPath.includes('generate.php');
    
    nav.innerHTML = `
        <a href="index.php" class="bottom-nav-item ${isHome ? 'active' : ''}">
            <div class="bottom-nav-icon">🏠</div>
            <span>Home</span>
        </a>
        <a href="generate.php?id=1" class="bottom-nav-item ${isGenerate ? 'active' : ''}">
            <div class="bottom-nav-icon">✨</div>
            <span>Create</span>
        </a>
        <a href="user/history.php" class="bottom-nav-item ${isHistory ? 'active' : ''}">
            <div class="bottom-nav-icon">🖼️</div>
            <span>Gallery</span>
        </a>
        <a href="user/profile.php" class="bottom-nav-item ${isProfile ? 'active' : ''}">
            <div class="bottom-nav-icon">👤</div>
            <span>Profile</span>
        </a>
    `;
    
    document.body.appendChild(nav);
    
    // Fix path issues for nested pages
    if (currentPath.includes('/user/')) {
        fixNavigationPaths();
    }
}

/**
 * Fixes navigation paths for nested pages
 */
function fixNavigationPaths() {
    const bottomNav = document.querySelector('.mobile-bottom-nav');
    if (bottomNav) {
        const links = bottomNav.querySelectorAll('a');
        links.forEach(link => {
            if (link.getAttribute('href').startsWith('index.php')) {
                link.setAttribute('href', '../index.php');
            }
            if (link.getAttribute('href').startsWith('generate.php')) {
                link.setAttribute('href', '../generate.php?id=1');
            }
        });
    }
}