/**
 * Error Handler for ByteBrain
 * 
 * This script provides standardized error handling functions
 * to ensure consistent error processing throughout the application.
 */

/**
 * Process and display error messages, handling object errors properly
 * @param {*} errorMessage - The error message or object to process
 * @returns {string} - A string representation of the error
 */
function processError(errorMessage) {
    // Handle case where errorMessage is an object
    let displayError = errorMessage;
    if (typeof errorMessage === 'object') {
        try {
            displayError = JSON.stringify(errorMessage, null, 2);
        } catch (e) {
            displayError = "Error object could not be displayed";
        }
    }
    return displayError;
}

/**
 * Process AJAX errors consistently
 * @param {object} xhr - The XHR object from the AJAX call
 * @param {string} status - The status from the AJAX call
 * @param {*} error - The error from the AJAX call
 * @returns {object} - An object with errorMessage and errorDetails
 */
function processAjaxError(xhr, status, error) {
    // Handle case where error is an object
    let displayError = error;
    if (typeof error === 'object') {
        try {
            displayError = JSON.stringify(error, null, 2);
        } catch (e) {
            displayError = "Error object could not be displayed";
        }
    }
    
    let errorMessage = displayError;
    let errorDetails = xhr.responseText || 'Unknown error occurred';
    
    // Check for connection refused (ComfyUI offline)
    if (xhr.status === 0 || xhr.status === 404 || error === 'error' || (typeof error === 'string' && error.includes('connect'))) {
        errorMessage = 'Image generation service is currently offline';
        errorDetails = 'The ComfyUI service is not available. Your request will be queued and processed when the service is back online.';
    } 
    // Check if response is HTML (often happens with PHP errors)
    else if (xhr.responseText && xhr.responseText.trim().startsWith('<')) {
        errorMessage = 'PHP error occurred (check error logs)';
    } else {
        try {
            const errorResponse = JSON.parse(xhr.responseText);
            if (errorResponse.error) {
                errorMessage = errorResponse.error;
            }
        } catch (e) {
            // Not valid JSON, use the error as is
        }
    }
    
    return {
        errorMessage: errorMessage,
        errorDetails: errorDetails
    };
}
